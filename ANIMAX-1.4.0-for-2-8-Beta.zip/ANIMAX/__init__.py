# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


try:
    from numpy import random as npr    
except: pass

try:
    from numpy import linspace
except: pass


if "npr" not in globals():
    message = ("\n\n"
        "The numpy library not found in this Blender built.\n"
        "Using the official Blender release will solve this problem.")
    raise Exception(message)

import bpy, time, os, string, blf
from random import uniform, choice, shuffle, seed
from mathutils import Vector, Euler, Matrix, noise, geometry
from math import pow, sqrt, sin, cos, pi
from bpy.app.handlers import persistent, frame_change_pre
from bpy.props import *
from bpy.types import PropertyGroup, UIList, Panel, Operator, Menu

# Add-on info
bl_info = {
    "name": "ANIMAX",
    "author": "Monaime Zaim (CodeOfArt.com)",
    "version": (1, 4, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Tools > ANIMAX",
    "description": "Procedural animation tool.",
    "warning": "Beta",
    "wiki_url": "http://codeofart.com/",
    "tracker_url": "http://codeofart.com/",      
    "category": "Animation"
    }
    
    
# Presets folder
presets_folder = os.path.join(os.path.dirname(__file__), "Presets")

############################################################################################
################################## Presets Management ######################################
############################################################################################

# Get the properties that are related to Custom mode
def get_custom_props():
    
    useless_props = ['custom_expand_loc', 'custom_expand_rot', 'custom_expand_scale',
                     'custom_push_away', 'custom_push_source', 'custom_start', 'custom_time',
                     'custom_in_out', 'custom_time_control']
                     
    subscriptable = ['custom_random', 'custom_additive', 'custom_neg']
                     
    coll, index = get_animax_collection()
    props = [i for i in dir(coll[index]) if ('custom_' in i) and (i not in useless_props)]
    props_dict = {}    
    for i in props:
        props_dict[i] = eval('coll[index].' + i + ('[:]' if i in subscriptable else ''))
        
    return props_dict

# Save a preset
def save_preset(name):
    scn = bpy.context.scene    
    active_preset = scn.animax_presets    
    props = get_custom_props()
    preset = os.path.join(presets_folder, name)
    with open(preset, 'w') as p:
        p.write(str(props))    
    presets = get_presets_list()    
    if active_preset in presets:
        scn.animax_presets = active_preset
    else:
        scn.animax_presets = scn.animax_presets    
        
        
# Load a Preset
def load_preset():
    dictionary = {}
    scn = bpy.context.scene
    coll, index = get_animax_collection()
    name = scn.animax_presets + '.animax'   
    preset = os.path.join(presets_folder, name)
    
    if os.path.exists(preset):
        with open(preset, 'r') as p:
            dictionary = eval(p.read())
        for i in dictionary:
            if hasattr(coll[index], i):
                exec('coll[index].' + i + '= dictionary["' + i + '"]')
                
# List of the Presets
def get_presets_list():
    presets = []
    if os.path.exists(presets_folder):       
        for p in os.listdir(presets_folder):
            if p.lower().endswith(".animax"):
                presets.append(p.replace(".animax", ""))    
    return presets

# List of the Presets (Enum)
def presets_list(self, context):
    presets = get_presets_list()
    empty = ('_Empty_', '_Empty_', '')            
    presets = [(i, i, '') for i in presets] if len(presets) > 0 else [empty]
    return presets

# Delete a preset file
def delete_preset():
    scn = bpy.context.scene
    name = scn.animax_presets + '.animax'   
    preset = os.path.join(presets_folder, name)
    if os.path.exists(preset):
        os.remove(preset)
        scn.animax_presets = scn.animax_presets
        
# Check if the preset's name already exists
def preset_name_exists(name):    
    if os.path.exists(presets_folder):       
        for p in os.listdir(presets_folder):
            if p == name:
                return True
    return False

# Rename a preset
def rename_preset(new_name):
    scn = bpy.context.scene
    name = scn.animax_presets + '.animax'   
    preset = os.path.join(presets_folder, name)
    new_name_path = os.path.join(presets_folder, new_name)
    if os.path.exists(preset):
        os.rename(preset, new_name_path)
        scn.animax_presets = scn.animax_presets
        
# Check if the all the characters have a valid format
# Symbols and non ascii chars are problematic
def are_chars_valid(text):
    digs = string.digits
    asci = string.ascii_letters
    symb = '_-() '    
    for i in text:
        if i not in (asci + digs + symb):
            return False        
    return True
    

            
############################################################################################
################################### Easing formulas ########################################
############################################################################################
    
Linear = lambda t, b, c, d : c*t/d + b

def InCubic(t, b, c, d):
    tc=(t/d)*t*t
    return b+c*(tc)

def OutCubic(t, b, c, d):
    ts=(t/d)*t
    tc=ts*t
    return b+c*(tc + -3*ts + 3*t)

def InOutCubic(t, b, c, d):
    ts=(t/d)*t
    tc=ts*t
    return b+c*(-2*tc + 3*ts)

def OutInCubic(t, b, c, d):
    ts=(t/d)*t
    tc=ts*t
    return b+c*(4*tc + -6*ts + 3*t)

def InCirc(t, b, c, d):
    t /= d
    return -c * (sqrt(1 - t*t) - 1) + b

def OutCirc(t, b, c, d):
    t /= d
    t -=1
    return c * sqrt(1 - t*t) + b

def OutBounce(t, b, c, d):
    if t/d < 1/2.75:
        return c*(7.5625*t*t) + b
    elif t < 2/2.75:
        t-=1.5/2.75
        return c*(7.5625*(t*t) + 0.75) + b
    elif t < 2.5/2.75:
        t-=(2.25/2.75)
        
        return c*(7.5625*(t*t) + .9375) + b
    else:
        t-=(2.625/2.75)
        return c*(7.5625*(t*t) + .984375) + b
    
def InBounce(t, b, c, d):
    return c - OutBounce(d-t, 0, c, d) + b

def InOutBounce(t, b, c, d):
    if t < 0.5:
        return (InBounce(t*2, 0.0, c, d) * 0.5) + b
    return OutBounce(t*2-d, 0.0, c, d) * 0.5 + (c*0.5) + b

def InExpo(t, b, c, d):
    return c * pow(2, 13 * (t-1)) + b if t != 0 else b

def OutExpo(t, b, c, d):
    return c * (-pow(2, -13 * t) + 1) + b if t != 1 else b + c   

def OutQuinticTwo(t, b, c, d):
	ts=(t/d)*t
	tc = ts*t
	return b+c*(2.2*tc*ts + -9.6*ts*ts + 16.6*tc + -14.2*ts + 6*t)

def InQuintic(t, b, c, d):
    ts=(t/d)*t
    tc = ts*t
    return b+c*(8.05*tc*ts + -12*ts*ts + 6*tc + -1.1*ts + 0.05*t)

def OutInQuintic(t, b, c, d):
    ts=(t/d)*t
    tc=ts*t
    return b+c*(-74*tc*ts + 195*ts*ts + -170*tc + 50*ts)

def linear(t, b, c, d):
    return (d-t)*b + t*c

def OutBackCubic(t, b, c, d):
    ts=(t/d)*t
    tc=ts*t
    return b+c*(-3*ts*ts + 10*tc + -12*ts + 6*t)

def InBackCubic(t, b, c, d):
    ts=(t/d)*t
    tc=ts*t
    return b+c*(4*tc + -3*ts)

def InOutBack(t, b, c, d):
    if t < 0.5:
        return (InBackCubic(t*2, 0.0, c, d) * 0.5) + b
    return OutBackCubic(t*2-d, 0.0, c, d) * 0.5 + (c*0.5) + b

def OutQuartic(t, b, c, d):
    ts=(t/d)*t
    tc = ts*t
    return b+c*(-1*ts*ts + 4*tc + -6*ts + 4*t)    

def OutQuintic(t, b, c, d):
    ts=(t/d)*t
    tc = ts*t
    return b+c*(tc*ts + -5*ts*ts + 10*tc + -10*ts + 5*t)

def InOutQuintic(t, b, c, d):
    ts=(t/d)*t
    tc = ts*t
    return b+c*(6*tc*ts -15*ts*ts + 10*tc)

def InElastic(t, b, c, d):
    ts=(t/d)*t
    tc = ts*t
    return b+c*(56*tc*ts + -105*ts*ts + 60*tc + -10*ts)

def OutElastic(t, b, c, d):
    ts=(t/d)*t
    tc=ts*t
    return b+c*(33*tc*ts + -106*ts*ts + 126*tc + -67*ts + 15*t)


def InOutElastic(t, b, c, d):
    if t < 0.5:
        return (InElastic(t*2, 0.0, c, d) * 0.5) + b
    return OutElastic(t*2-d, 0.0, c, d) * 0.5 + (c*0.5) + b

def OutInQuartic(t, b, c, d):
    ts=(t/d)*t
    tc=ts*t
    return b+c*(6*tc + -9*ts + 4*t)


# Group the easing Functions in a Dictionary to call them easily
easing = {'Linear':Linear, 'InQuintic':InQuintic, 'OutQuintic':OutQuintic,
          'InOutQuintic':InOutQuintic, 'InElastic':InElastic, 'OutElastic':OutElastic,
          'InBounce':InBounce, 'OutBounce':OutBounce, 'InExpo':InExpo,
          'OutExpo':OutExpo, 'InBackCubic':InBackCubic, 'OutBackCubic':OutBackCubic,
          'InCirc':InCirc, 'OutCirc':OutCirc, 'InCubic':InCubic, 'OutCubic':OutCubic,
          'InOutCubic':InOutCubic, 'OutInCubic':OutInCubic, 'InOutElastic':InOutElastic,
          'InOutBounce':InOutBounce, 'InOutBack':InOutBack, 'OutInQuintic':OutInQuintic,
          'OutInQuartic':OutInQuartic}
          
# Apply easing to multiple axis at once
def vector_easing(t, b, c, ease_type):    
    x, y, z = [easing[ease_type](t, b[i], c[i]-b[i], 1.0) for i in range(3)]
    return (x ,y, z)


############################################################################################
################################### General Utils ##########################################
############################################################################################

# List of all the Easing formulas
def easing_list(self, context):
    
    ease_list = ['Linear', 'InQuintic', 'OutQuintic', 'InOutQuintic', 'OutInQuintic',
                 'InElastic', 'OutElastic', 'InOutElastic', 'InBounce', 'OutBounce',
                 'InOutBounce', 'InExpo', 'OutExpo', 'InBackCubic', 'OutBackCubic',
                 'InOutBack', 'InCirc', 'OutCirc', 'InCubic', 'OutCubic', 'InOutCubic',
                 'OutInCubic', 'OutInQuartic']
                 
    icons = ['IPO_LINEAR', 'IPO_QUINT', 'IPO_QUINT', 'IPO_EASE_IN_OUT', 'IPO_BEZIER',
             'IPO_ELASTIC', 'IPO_ELASTIC', 'IPO_EASE_IN_OUT', 'IPO_BOUNCE',
             'IPO_BOUNCE', 'IPO_EASE_IN_OUT', 'IPO_EXPO', 'IPO_EXPO', 'IPO_BACK',
             'IPO_BACK', 'IPO_EASE_IN_OUT', 'IPO_CIRC', 'IPO_CIRC', 'IPO_EASE_IN',
             'IPO_EASE_OUT', 'IPO_EASE_IN_OUT', 'IPO_BEZIER', 'IPO_BEZIER']             
                 
    return [(i, i, '', icons[j], j) for j, i in enumerate(ease_list)]

# List of all the FX
def effects(self, context):
    fx_list = ['None', 'Transformer', 'Shoot', 'Explode', 'Sparks',
               'Sparks_II', 'Streaks', 'Popcorn', 'Butterflies', 'Smooth',
               'Smooth_II','Spiral', 'Wiggle', 'Zigzag', 'Rain',
               'Elastic', 'Collapse', 'Copy_animation', 'Follow_Curve', 'Custom']
    return [(i, i, '') for i in fx_list]    

# List of available collections
def collections_list(self, context):
    collections = bpy.data.collections
    coll = context.scene.animax_collection.coll    
    return [(i.name, i.name, '') for i in collections if not i.name in coll and len(i.objects)>0]

# Calculate the distance between two Vectors
def get_distance(v1, v2):
    l = [v1, v2]
    d = sqrt( (l[0][0] - l[1][0])**2 + (l[0][1] - l[1][1])**2 + (l[0][2] - l[1][2])**2)
    return d

# Multiply two Vectors
def mult(vec, vec2):
    temp = []
    for x, i in enumerate(vec):
        temp.append(i * vec2[x])

    return Vector(temp)

# Convert the WORLD Rotation to LOCAL (driven by the Delta Rotation)
def world_to_local_rot(ob, rotation):
    
    x, y, z = (ob.rotation_euler[i] + rotation[i] for i in range(3))    
    
    euler = Euler((x, y, z), 'XYZ')
    
    loc, rot, scale = (ob.location, ob.rotation_euler, ob.scale)

    smat = Matrix()
    for i in range(3):
        smat[i][i] = scale[i]

    mat = Matrix.Translation(loc) @ rot.to_matrix().to_4x4() @ smat
    
    rot_mat = euler.to_matrix().to_4x4() @ mat.inverted()
    
    return rot_mat.to_euler()

# Sort objects
def sort_objects(group, direction = 'all', se = 0):
    scn = bpy.context.scene
    grp = bpy.data.collections[group]
    obs = grp.objects    
    count = len(obs)
    
    ran = list(range(count))
    
    if direction == 'random' or direction == 'all':
        seed(se)        
        shuffle(ran)
        if direction == 'random':
            return ran
    
    if direction == 'xyz' or direction == 'all':
        x = [(ob.location.x, i) for i, ob in enumerate(obs)]
        y = [(ob.location.y, i) for i, ob in enumerate(obs)]
        z = [(ob.location.z, i) for i, ob in enumerate(obs)]
        
        x.sort()    
        y.sort()    
        z.sort()
        
        sx = [j for (i, j) in x]
        sy = [j for (i, j) in y]
        sz = [j for (i, j) in z]
        
        rev_x = sx[::-1]          
        rev_y = sy[::-1]
        rev_z = sz[::-1]
        
        if direction == 'xyz':
            return (sx, sy, sz, rev_x, rev_y, rev_z)
    
    if direction == 'cursor' or direction == 'all':
        cur_loc = bpy.context.scene.cursor_location
        cur = [(get_distance(ob.matrix_world.to_translation(), cur_loc), i) for i, ob in enumerate(obs)]        
        cur.sort()
        scur = [j for (i, j) in cur]
        rev_cur = scur[::-1]
        
        if direction == 'cursor':
            return (scur, rev_cur)
    
    if direction == 'custom' or direction == 'all':
        if 'animax_selection' in scn:
            custom = scn['animax_selection']
            custom_in_group = [ob for ob in custom if scn.objects.get(ob) in obs[:]]
            custom_left = [ob.name for ob in obs if ob.name not in custom]
            custom = custom_in_group + custom_left
            cus = [obs[:].index(scn.objects[ob]) for ob in custom]
        else:
            scn['animax_selection'] = []
            cus = ran
            
        rev_cus = cus[::-1]
        
        if direction == 'custom':
            return (cus, rev_cus)    
    
    return (sx, sy, sz, scur, cus, rev_x, rev_y, rev_z, rev_cur, rev_cus, ran, count)

# Add a single collection
def add_single_collection(collection):
    scn = bpy.context.scene      
    if not 'animax_sorted_colls' in scn:
        scn['animax_sorted_colls'] = {}
    collections = [x.name for x in scn.animax_collection.coll]
    if not collection in collections:
        item = scn.animax_collection.coll.add()
        item.name = collection
        item.name_originale = collection                
        if not collection in scn['animax_sorted_colls']:
            dictionary = {
                          'X':[],'Y':[],'Z':[], 'Cursor':[], 'Custom':[],
                          '-X':[],'-Y':[],'-Z':[], '-Cursor':[], '-Custom':[],
                          'Random':[],'Count':0
                          }            
            scn['animax_sorted_colls'][collection] = dictionary
    

# Add a collections to the list (update function)
def add_collection(self, context):
    scn = bpy.context.scene
    group = scn.animax_avail_collections
    add_single_collection(group)        
    return None

# Add all available collections
def add_all_collections():
    scn = bpy.context.scene
    collections = bpy.data.collections
    if len(collections)>0:        
        collection = [x.name for x in scn.animax_collection.coll]    
        avail_collections =  [i.name for i in collections if not i.name in collection and len(i.objects)>0]
        for g in avail_collections:
            add_single_collection(g)    

# Delete collection
def delete(all = False):
    scn = bpy.context.scene
    coll, index = get_animax_collection()
    if not all:            
        if len(coll) >0:
            if coll[index].name in scn['animax_sorted_colls']:
                del scn['animax_sorted_colls'][coll[index].name]
            if coll[index].name in bpy.data.collections:
                clear_delta(coll[index].name)                                       
            coll.remove(index)        
            if index >0:
                scn.animax_collection.index = (index - 1)
    else:
        if len(coll) >0:
            for i in range(len(coll))[::-1]:
                if coll[i].name in scn['animax_sorted_colls']:
                    del scn['animax_sorted_colls'][coll[i].name]
                if coll[i].name in bpy.data.collections:
                    clear_delta(coll[i].name)                                       
                coll.remove(i)
                
# Enable/Disable collections
def enable_collections(type = 'Enable'):
    coll, index = get_animax_collection()
    if len(coll) > 0:        
        if type == 'Enable':            
            for i in range(len(coll)):                
                coll[i].fx_enabled = True
        elif type == 'Disable':
            for i in range(len(coll)):
                coll[i].fx_enabled = False
        else:
            for i in range(len(coll)):
                coll[i].fx_enabled = False
            coll[index].fx_enabled = True
            
# Clear delta transform
def clear_delta(collection):    
    collections = bpy.data.collections    
    if collection in collections:
        objects = collections[collection].objects
        if len(objects)>0:
            for ob in objects:
                ob.delta_location = (0.0, 0.0, 0.0)
                ob.delta_rotation_euler = (0.0, 0.0, 0.0)
                ob.delta_scale = (1.0, 1.0, 1.0)
                    
                
#  ANIMAX active collection
def get_animax_collection():
    coll = bpy.context.scene.animax_collection.coll
    index = bpy.context.scene.animax_collection.index   
    return (coll, index)


# Update the name of the collection
def update_prop_name(self, context):
    scn = context.scene
    coll, index = get_animax_collection()
    collections = bpy.data.collections    
    new_name = self.name
    name = self.name_originale
    try:
        if name in scn['animax_sorted_colls']:
            scn['animax_sorted_colls'][new_name] = scn['animax_sorted_colls'].pop(name)
        else:
            dictionary = {
                          'X':[],'Y':[],'Z':[], 'Cursor':[], 'Custom':[],
                          '-X':[],'-Y':[],'-Z':[], '-Cursor':[], '-Custom':[],
                          'Random':[],'Count':0
                          }          
            scn['animax_sorted_colls'][new_name] = dictionary
                                    
    except Exception as error:
        print('Error in update name: ', error)
    finally:
        coll[new_name].name_originale = new_name
        
                
    return None

# Update the FX when the properties changes
def update_time_props(self, context):
    scn = context.scene
    interactive = scn.animax_interactive
    if interactive:
        update_fx(scn)        
    return None

# Update the FX when the properties changes (Hacky!!!)
def update_props(self, context):
    scn = context.scene
    interactive = scn.animax_interactive
    if interactive:        
        scn.frame_current = scn.frame_current
    return None

# Draw text for the Selection Order operator
def draw_callback(self, context):    
    font_id = 0
    blf.enable(0, blf.SHADOW)
    blf.position(font_id, 15, 30, 0)
    blf.size(font_id, 20, 72)
    blf.color(font_id, 0.0, 1.0, 0.0, 0.8)
    blf.shadow(font_id, 3, 0.0, 0.0, 0.0, 0.8)
    blf.shadow_offset(font_id, 1, -2)
    blf.draw(font_id, "Press Escap or Enter to exit.")
    
############################################################################################
###################################### FX Utils ############################################
############################################################################################

# Get available fcurves (loc, rot, scale)
def avail_fcurves(OBname):
    scn = bpy.context.scene
    obj = scn.objects    
    fcs, index, ranges, starts = ([], [], [0], [1])
    if obj.get(OBname):
        ob = obj[OBname]
        if hasattr(ob.animation_data, 'action'):
            if hasattr(ob.animation_data.action, 'fcurves'):                    
                fc = ob.animation_data.action.fcurves            
                for i in range(len(fc)):
                    if fc[i].data_path in ['location', 'rotation_euler', 'scale']:
                        rang = fc[i].range()
                        ranges.append(rang[1]- rang[0])
                        starts.append(rang[0])
                        fcs.append(fc[i].data_path + str(fc[i].array_index))
                        index.append(i)
    return (fcs, index, max(ranges), min(starts))

# Get the points of a Curve
def get_curve_points(curve):
    points = []
    bezier_points = []
    
    if len(curve.data.splines) > 0:        
        spline = curve.data.splines[0]
        if spline.type == 'BEZIER':
            if len(spline.bezier_points) >= 2:
                r = spline.resolution_u + 1
                segments = len(spline.bezier_points)
                if not spline.use_cyclic_u:
                    segments -= 1        
                for i in range(segments):
                    inext = (i + 1) % len(spline.bezier_points)
                    knot1 = spline.bezier_points[i].co
                    handle1 = spline.bezier_points[i].handle_right
                    handle2 = spline.bezier_points[inext].handle_left
                    knot2 = spline.bezier_points[inext].co
                    _points = geometry.interpolate_bezier(knot1, handle1, handle2, knot2, r)
                    points.extend(_points)
            if len(points) > 0:        
                for p in points:
                    bezier_points.append(p-points[0])                   
            
    return bezier_points          

# Split the duration to segments (for the transformers effect)
def segments(start, duration):
    seg_1 = round((duration)*0.2) + start
    seg_2 = round((duration)*0.3) + seg_1
    seg_3 = (seg_2*2) - seg_1
    return (seg_1, seg_2, seg_3)

# A function to determine the first frame of the animation for an object
def get_start_frame(frame, index, count, start_f, duration_of, direction):             
    start = start_f
    if not duration_of == 0:
        if count > 1:                
            if frame >=start_f:
                start = start_f + int(index *(duration_of/count))        
    return start

############################################################################################
##################################### FX functions #########################################
############################################################################################

# The transformrs effect
def transform(frame, start, duration, distance, push, push_loc, se, index):
    npr.seed(index+se)
    location = npr.uniform(-distance, distance, size = 3)
    if push:
        dis = npr.uniform(0.005, distance*.75)        
        loc_2 = push_loc * distance * dis
    else:
        loc_2 = (0.0, 0.0, location[2])
        ran = npr.choice([1,2,3])
        loc_2 = (0.0, location[1], 0.0) if ran == 2 else (location[0], 0.0, 0.0) if ran == 3 else loc_2
    rotation = npr.uniform(-(pi/2), (pi/2), size = 3)       
         
        
    seg_1, seg_2, seg_3 = segments(start, duration)
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (1.0, 1.0, 1.0)]
    
    if frame in range(start, seg_1+1):
        t= (frame - start) / (seg_1+1-start)
        sca = OutQuinticTwo(t, 0.0, 1.0, 1.0)
        loc = (location[0], location[1], location[2])
        rot = (rotation[0], rotation[1], rotation[2])
        scale = (sca, sca, sca) 
        
        
    elif frame in range(seg_1+1, seg_2+1):
        t= (frame - seg_1+1) / (seg_2-seg_1+1)
        if index % 2 == 0:
            loc_0 = OutQuintic(t, location[0], loc_2[0]-location[0], 1.0)
            loc_1 = OutQuintic(t, location[1], loc_2[1]-location[1], 1.0)
            loc_2 = OutQuintic(t, location[2], loc_2[2]-location[2], 1.0)        
            loc = (loc_0, loc_1, loc_2)
            rot = (rotation[0], rotation[1], rotation[2])    
        else: 
            rot_0 = OutQuintic(t, rotation[0], -rotation[0], 1.0)
            rot_1 = OutQuintic(t, rotation[1], -rotation[1], 1.0)
            rot_2 = OutQuintic(t, rotation[2], -rotation[2], 1.0)
            loc = (location[0], location[1], location[2])
            rot = (rot_0, rot_1, rot_2)       
        
    elif frame in range(seg_2+1, seg_3+1):        
        t= (frame - seg_2+1) / (seg_3-seg_2+1)
        if index % 2 == 0:
            rot_0 = OutQuintic(t, rotation[0], -rotation[0], 1.0)
            rot_1 = OutQuintic(t, rotation[1], -rotation[1], 1.0)
            rot_2 = OutQuintic(t, rotation[2], -rotation[2], 1.0)
            loc = (loc_2[0], loc_2[1], loc_2[2])
            rot = (rot_0, rot_1, rot_2)   
        else:
            loc_0 = OutQuintic(t, location[0], loc_2[0]-location[0], 1.0)
            loc_1 = OutQuintic(t, location[1], loc_2[1]-location[1], 1.0)
            loc_2 = OutQuintic(t, location[2], loc_2[2]-location[2], 1.0)
            loc = (loc_0, loc_1, loc_2)
            rot = (0, 0, 0)
        
    elif frame in range(seg_3+1, duration+start+1):        
        t= (frame - seg_3+1) / (duration+start-seg_3+1)
        loc_0 = linear(t, loc_2[0], 0, 1.0)
        loc_1 = linear(t, loc_2[1], 0, 1.0)
        loc_2 = linear(t, loc_2[2], 0, 1.0)
        loc = (loc_0, loc_1, loc_2)        
    
    return [loc, rot, scale]

# The Shoot effect
def shoot(frame, start, duration, source, ob, shoot_ease, index):
    obj = bpy.context.scene.objects    
    own = obj[ob].matrix_world.to_translation() - obj[ob].delta_location
    src =source- own
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (1.0, 1.0, 1.0)]    
    
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)
        sca = OutQuinticTwo(t, 0.0, 1.0, 1.0)        
        loc = vector_easing(t, src, (0.0, 0.0, 0.0), shoot_ease)               
        scale = (sca, sca, sca)
    return [loc, rot, scale] 

# The Explode effect
def explode(frame, start, duration, velocity, gravity, rotation, up, ran, se, index):        
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]    
    npr.seed(index+se)
    x = npr.uniform(-velocity[0], velocity[0]) if ran[0] else velocity[0]
    y = npr.uniform(-velocity[1], velocity[1]) if ran[1] else velocity[1]
    z =  npr.uniform(velocity[2]*0.1, velocity[2]) if ran[2] else velocity[2]
    rots = npr.uniform(-rotation, rotation, size=3)
        
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)
        rot = vector_easing(t, (0.0, 0.0, 0.0), rots, 'Linear')
        sca = linear(t, 1.0, 0.0, 1.0)        
        loc_0 = (x*t)
        if up == 'Z':
            loc_1 = (y*t)
            loc_2 = -gravity*pow(t,2) + (z*t)
        else:
            loc_2 = (y*t)
            loc_1 = -gravity*pow(t,2) + (z*t)               
        
        loc = (loc_0, loc_1, loc_2)       
        scale = (sca, sca, sca)
    return [loc, rot, scale] 

# The Sparks effect
def sparks(frame, start, duration, distance, distance2, rotation, up, ran, se, index):        
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]
    npr.seed(index+se)
    rots = npr.uniform(-rotation, rotation, size=3)
    dis = npr.uniform(distance/2, distance)
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)
                        
        if distance2 > 0:            
            p = npr.uniform(-ran, ran, size = (2, 3))
            x = noise.variable_lacunarity((p[0][0]*t, p[0][1]*t, p[0][2]*t), 0)*distance2*t
            y = noise.variable_lacunarity((p[1][0]*t, p[1][1]*t, p[1][2]*t), 0)*distance2*t
            z = 0.0
            nois = Vector((x, y, z))
        else:
            nois = Vector((0.0, 0.0, 0.0))     
        loc_0 = nois[0]
        if up == 'Z' :
            loc_1 = nois[1]
            loc_2 = InOutQuintic(t, 0.0, dis, 1)
        else:
            loc_2 = nois[1]
            loc_1 = InOutQuintic(t, 0.0, dis, 1)
             
        sca = InQuintic(t, 1.0, -1.0, 1.0)
        rot = vector_easing(t, (0.0, 0.0, 0.0), rots, 'InOutQuintic')                 
        loc = (loc_0, loc_1, loc_2)               
        scale = (sca, sca, sca)
    return [loc, rot, scale]

# The Sparks-II effect
def sparksii(frame, start, duration, distance, distance2, up, se, index):        
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]
    seed(index+se)
    loc_x = uniform(-distance2, distance2)
    rot_x = uniform(0, 2*pi)    
    seed(index+se+1)
    if up == 'Z':
        loc_y = uniform(-distance2, distance2)
        seed(index+se+2)
        loc_z = uniform(0.1, distance)
    else:
        loc_z = uniform(-distance2, distance2)
        seed(index+se+2)
        loc_y = uniform(0.1, distance)            
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)
        sca = linear(t, 1.0, 0.0, 1.0) 
        rota = linear(t, 0.0, rot_x, 1.0)       
        loc_0 = loc_x * sin(pi*t) if index%2 == 0 else -loc_x * sin(pi*t)
        if up == 'Z' :
            loc_1 = loc_y * sin(pi*t) if index%2 == 0 else -loc_y * sin(pi*t)
            loc_2 = linear(t, 0, distance, 1)
        else:
            loc_2 = loc_z * sin(pi*t) if index%2 == 0 else -loc_z * sin(pi*t)
            loc_1 = linear(t, 0, distance, 1)                
        
        loc = (loc_0, loc_1, loc_2)
        rot = (rota, rota, rota)       
        scale = (sca, sca, sca)
    return [loc, rot, scale]

# The Streaks effect
def streaks(frame, start, duration, distance, se, index):        
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]
    seed(index+se)
    r_x, r_y, r_z = (uniform(-pi, pi) for _ in range(3))
    
    if frame < start:
        loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (1.0, 1.0, 1.0)]
        
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)
        dis = distance if t > 0 else 1        
        ran = choice([1,2,3])
        sca = OutQuinticTwo(t, 1.0, -1.0, 1.0)
        sca_x = ((dis * sin(pi*t)) + (1-t)) if ran == 1 else sca
        sca_y = ((dis * sin(pi*t)) + (1-t)) if ran == 2 else sca
        sca_z = ((dis * sin(pi*t)) + (1-t)) if ran == 3 else sca      
        
        rot = vector_easing(t, (0.0, 0.0, 0.0), (r_x, r_y, r_z), 'InOutQuintic')            
        scale = (sca_x, sca_y, sca_z)
    return [loc, rot, scale]

# The Popcorn effect
def popcorn(frame, start, duration, distance, rotation, scl, se, index):        
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]
    npr.seed(index+se)
    rots = npr.uniform(-rotation, rotation, size=3)
    loc_x, loc_y, loc_z = npr.uniform(-distance, distance, size=3)
        
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)        
        sca = (scl * sin(pi*t)) + (1-t)
        x = (loc_x * sin(pi*t)) 
        y = (loc_y * sin(pi*t))
        z = (loc_z * sin(pi*t))
        loc = (x, y, z) 
        rot = vector_easing(t, (0.0, 0.0, 0.0), rots, 'InOutQuintic')         
        scale = (sca, sca, sca)
    return [loc, rot, scale]    

# The Smooth effect
def smooth(frame, start, duration, distance, rotation, se, index):        
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]
    npr.seed(index+se)    
    locs = npr.uniform(-distance, distance, size=9)
    rots = npr.uniform(0, rotation, size=3)    
                
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)
        sca = InQuintic(t, 1.0, -1.0, 1.0)
        rot = vector_easing(t, (0.0, 0.0, 0.0), rots, 'InOutQuintic')      
        loc_0 = (3*(1-t)*(1-t)*t*locs[2])+(3*(1-t)*(1-t)*t*t*locs[1])+(t*t*t*locs[0])
        loc_1 = (3*(1-t)*(1-t)*t*locs[5])+(3*(1-t)*(1-t)*t*t*locs[4])+(t*t*t*locs[3])
        loc_2 = (3*(1-t)*(1-t)*t*locs[8])+(3*(1-t)*(1-t)*t*t*locs[7])+(t*t*t*locs[6])        
        loc = (loc_0, loc_1, loc_2)                     
        scale = (sca, sca, sca)
    return [loc, rot, scale]

# The Butterflies effect
def butterflies(frame, start, duration, distance, vibration, angle, se, index):        
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]
    seed(index+se)
    loc_x,loc_y,loc_z,loc_x_2,loc_y_2,loc_z_2=(uniform(-distance, distance) for _ in range(6))
    rot_x, rot_y, rot_z = (uniform(0, angle) for _ in range(3))
       
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)
        sca = linear(t, 1.0, 0.0, 1.0) 
        rot_0 = rot_x*sin(pi*frame/(12-vibration)) * t    
        rot_1 = rot_y*sin(pi*frame/(12-vibration)) * t
        rot_2 = rot_z*sin(pi*frame/(12-vibration)) * t
        
        loc_0 = (2*(1-t)*t*((loc_x_2)))+(t*t*loc_x)
        loc_1 = (2*(1-t)*t*((loc_y_2)))+(t*t*loc_y)
        loc_2 = (2*(1-t)*t*((loc_z_2)))+(t*t*loc_z)               
        
        loc = (loc_0, loc_1, loc_2)
        rot = (rot_0, rot_1, rot_2)       
        scale = (sca, sca, sca)
    return [loc, rot, scale]

# The Spiral effect
def spiral(frame, start, duration, distance, offset, turns, up, se, index):        
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]
    
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)
        t*=t
        sca = InQuintic(t, 1.0, -1.0, 1.0)        
        loc_x = distance * cos(turns*2*pi*t) * t        
        loc_z = distance * sin(turns*2*pi*t) * t
        loc = (loc_x, offset * t * t, loc_z)
        if up == 'Z' :
            loc = (loc_x, loc_z, offset * t * t)
        elif up == 'X':
            loc = (offset * t * t, loc_x, loc_z)
        elif up == 'Random':
            npr.seed(index+se)
            r = npr.uniform(-1.0,1.0)
            dis = distance * r * t
            loc_x = dis * r * cos(turns*2*pi*r*t)
            loc_z = dis * r * sin(turns*2*pi*r*t)
            ran = npr.choice([1,2,3])
            if ran == 1:
                loc = (loc_x, dis, loc_z)
            elif ran == 2:
                loc = (loc_x, loc_z, dis)
            else: loc = (dis, loc_x, loc_z)     
                                
        scale = (sca, sca, sca)    
    return [loc, rot, scale]

# The Smooth II effect
def smoothii(frame, start, duration, distance, rotation, turns, se, index):    
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]
    npr.seed(index+se)
    turn = npr.uniform(-turns, turns, size=9)
    dis = npr.uniform(-distance, distance, size=3)
    rots = npr.uniform(0, rotation, size=3)
    
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration) 
        t2 = sqrt(t)       
        sca = InQuintic(t, 1.0, -1.0, 1.0)        
        loc_x = (dis[0] * sin(turn[0]*pi/2*t2) * sin(turn[1]*pi/2*t2) * sin(turn[2]*pi/2*t2) * t*5/6) + (dis[0]/6*t2*t2)
        loc_y = (dis[1] * cos(turn[3]*pi/2*t2) * cos(turn[4]*pi/2*t2) * cos(turn[5]*pi/2*t2) * t*5/6) + (dis[1]/6*t2*t2)
        loc_z = (dis[2] * sin(turn[6]*pi/2*t2) * cos(turn[7]*pi/2*t2) * sin(turn[8]*pi/2*t2) * t*5/6) + (dis[2]/6*t2*t2)
        loc = (loc_x, loc_y, loc_z)
        rot = vector_easing(t, (0.0, 0.0, 0.0), rots, 'InOutQuintic')
        scale = (sca, sca, sca)
    
    return [loc, rot, scale]

# The Wiggle effect
def wiggle(frame, start, duration, distance, rotation, comp, distortion, se, index):    
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]
    npr.seed(index+se)    
    pos = npr.uniform(-comp, comp, size = (3, 3))
    rots = npr.uniform(0, rotation, size=3)
    
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)        
        sca = InQuintic(t, 1.0, -1.0, 1.0)        
        loc_x = noise.variable_lacunarity((pos[0][0]*t, pos[0][1]*t, pos[0][2]*t), distortion)*distance *t
        loc_y = noise.variable_lacunarity((pos[1][0]*t, pos[1][1]*t, pos[1][2]*t), distortion)*distance *t
        loc_z = noise.variable_lacunarity((pos[2][0]*t, pos[2][1]*t, pos[2][2]*t), distortion)*distance *t
        loc = (loc_x, loc_y, loc_z)
        rot = vector_easing(t, (0.0, 0.0, 0.0), rots, 'InOutQuintic')
        scale = (sca, sca, sca)
    
    return [loc, rot, scale]

# The Zigzag effect
def zigzag(frame, start, duration, distance, rotation, se, index):
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (1.0, 1.0, 1.0)]
    npr.seed(index+se)
    locs = npr.uniform(-distance, distance, size = (3, 3))
    rots = npr.uniform(-rotation, rotation, size = (3, 3))        
    seg_0, seg_1, seg_2 = linspace(start, start + duration, 3, endpoint = False)
    seg_1, seg_2 = int(seg_1), int(seg_2)    
    
    if frame in range(start, seg_1+1):
        t= (frame - start) / (seg_1+1-start)
        sca = OutQuinticTwo(t, 0.0, 1.0, 1.0)
        loc = vector_easing(t, locs[2], locs[1], 'InOutQuintic')
        rot = vector_easing(t, rots[2], rots[1], 'InOutQuintic')
        scale = (sca, sca, sca) 
        
        
    elif frame in range(seg_1+1, seg_2+1):
        t= (frame - seg_1+1) / (seg_2-seg_1+1)
        loc = vector_easing(t, locs[1], locs[0], 'InOutQuintic')
        rot = vector_easing(t, rots[1], rots[0], 'InOutQuintic')
              
        
    elif frame in range(seg_2+1, duration+start+1):        
        t= (frame - seg_2+1) / (duration+start-seg_2+1)
        loc = vector_easing(t, locs[0], (0.0, 0.0, 0.0), 'InOutQuintic')
        rot = vector_easing(t, rots[0], (0.0, 0.0, 0.0), 'InOutQuintic')
            
    return [loc, rot, scale]

# The Rain effect
def rain(frame, start, duration, distance, length, up, index):
    loc, rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]        
        
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)        
        sca = OutCirc(t, 1.0, -1.0, 1.0)
        sca_v = OutExpo(t, 1.0, length-1.0, 1.0) 
        loc_v = OutCubic(t, 0.0, distance, 1)
        loc = (0.0, 0.0, loc_v) if up == 'Z' else (0.0, loc_v, 0.0)
        scale = (sca, sca, sca_v)
        if up == 'Y':
            scale = (sca, sca_v, sca)                
    
    return [loc, rot, scale]

# The Collapse effect
def collapse(frame, start, duration, floor, s_scale, rotation, spread, f_axis, se, index):
    rot = rotation
    scale = (0.0, 0.0, 0.0) if s_scale else (1.0, 1.0, 1.0)
    seed(index+se)
    loc_x,loc_y = (uniform(-spread, spread) for _ in range(2))    
    loc = (loc_x, floor, loc_y) if f_axis == 'Y' else (floor, loc_x, loc_y) if f_axis == 'X' else (loc_x, loc_y, floor)
    
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)        
        loc = vector_easing(t, (0.0, 0.0, 0.0), loc, 'InOutCubic')
        rot = vector_easing(t, (0.0, 0.0, 0.0), rotation, 'InOutCubic')
        sca = InQuintic(t, 1.0, -1.0, 1.0) if s_scale else 1.0                   
        scale = (sca, sca, sca)
                
    return [loc, rot, scale]

# The Elastic effect
def elastic(frame, start, duration, location, rotation, s_start, s_amplitude, elasticity, slow, index):
    loc = location
    rot = rotation
    scale = (s_start, s_start, s_start)
    
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)        
        loc_x = sin((pi/2)*t*((elasticity[0]*4)-3)) * (loc[0] * pow(t, slow[0]))
        loc_y = sin((pi/2)*t*((elasticity[0]*4)-3)) * (loc[1] * pow(t, slow[0]))
        loc_z = sin((pi/2)*t*((elasticity[0]*4)-3)) * (loc[2] * pow(t, slow[0]))
        
        rot_x = sin((pi/2)*t*((elasticity[1]*4)-3)) * (rot[0] * pow(t, slow[1]))
        rot_y = sin((pi/2)*t*((elasticity[1]*4)-3)) * (rot[1] * pow(t, slow[1]))
        rot_z = sin((pi/2)*t*((elasticity[1]*4)-3)) * (rot[2] * pow(t, slow[1]))
        
        bnc = abs(cos((pi/2)*t*((elasticity[2]*4)-3)) * (pow(t, slow[2]) * (s_amplitude-s_start)))
        sca = bnc + (1 - pow(t, slow[2])) + (s_start * pow(t, slow[2]))
        
        loc = (loc_x, loc_y, loc_z)        
        rot = (rot_x, rot_y, rot_z)
        scale = (sca, sca, sca)
        
    return [loc, rot, scale]

# The Copy animation effect
def copy_animation(frame, start, duration, OBname):        
    loc, rot, scale = [[0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [1.0, 1.0, 1.0]]
    obj = bpy.context.scene.objects    
    if obj.get(OBname):
        src = obj[OBname]
        fcs, indexs, range, starts = avail_fcurves(OBname)
        if fcs != []:
            action = src.animation_data.action
            for fc, ind in zip(fcs, indexs):
                evaluate = frame-start+starts
                if 'location' in fc:
                    loc[int(fc[-1:])] = action.fcurves[ind].evaluate(evaluate)
                elif 'rotation_euler' in fc:
                    rot[int(fc[-1:])] = action.fcurves[ind].evaluate(evaluate)
                elif 'scale' in fc:
                    scale[int(fc[-1:])] = action.fcurves[ind].evaluate(evaluate) 
        
    return [tuple(loc), tuple(rot), tuple(scale)]

# The Follow Curve
def follow(frame, start, duration, points, c_scale, c_rot, ran, ran_freq, se, index):
    loc = points[0] if len(points) > 0 else (0.0, 0.0, 0.0)    
    rot, scale = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]
    nois = Vector((0.0, 0.0, 0.0))    
        
    if frame in range(start, duration+start+1):
        t= (frame - start) / (duration)
        npr.seed(index+se)
        rots = npr.uniform(-c_rot, c_rot, size=3)
        
        if ran > 0:            
            p = npr.uniform(-ran_freq, ran_freq, size = (3, 3))
            x = noise.variable_lacunarity((p[0][0]*t, p[0][1]*t, p[0][2]*t), 0)*ran*t
            y = noise.variable_lacunarity((p[1][0]*t, p[1][1]*t, p[1][2]*t), 0)*ran*t
            z = noise.variable_lacunarity((p[2][0]*t, p[2][1]*t, p[2][2]*t), 0)*ran*t
            nois = Vector((x, y,z))            
                
        loc = (points[int((len(points)-1)*t)] * c_scale) + nois
        rot = vector_easing(t, (0.0, 0.0, 0.0), rots, 'InOutQuintic')
        sca = InQuintic(t, 1.0, -1.0, 1.0)        
        scale = (sca, sca, sca)
    
    return [loc, rot, scale]

# The Custom mode
def custom(frame, start, duration, location, rotation, scale, loc_ease, rot_ease, scale_ease, rand, neg_ran, additive, push, push_loc, se, index): 
    seed(index+se)
    if push:
        # Vector(x * y for x, y in zip(push_loc ,location))
        loc = mult(push_loc ,location)
        location = loc
    loc =  [uniform(-location[i] if neg_ran[0] else 0.0, location[i]) * rand[0] for i in range(3)] if rand[0]>0 else location
    loc = [i + j for i, j in zip(loc, location)] if additive[0] and rand[0]>0 else loc
    
    rot =  [uniform(-rotation[i] if neg_ran[1] else 0.0, rotation[i]) * rand[1] for i in range(3)] if rand[1]>0 else rotation
    scal =  [uniform(-scale[i] if neg_ran[2] else 0.0, scale[i]) * rand[2] for i in range(3)] if rand[2]>0 else scale
    
    
    rot = [i + j for i, j in zip(rot, rotation)] if additive[1] and rand[1]>0 else rot
    scal = [i + j for i, j in zip(scal, scale)] if additive[2] and rand[2]>0 else scale     
        
    if frame in range(start, duration+start+1):
        
        t= (frame - start) / (duration)              
        loc = vector_easing(t, (0.0, 0.0, 0.0), loc, loc_ease)
        rot = vector_easing(t, (0.0, 0.0, 0.0), rot, rot_ease)
        scal = vector_easing(t, (1.0, 1.0, 1.0), scal, scale_ease)
    return [loc, rot, scal]

############################################################################################
#################################### Apply the FX ##########################################
############################################################################################

def Transformer(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.transformer_start
    duration_per_ob = g.transformer_duration_per_ob
    duration_offset = g.transformer_duration_offset
    distance = g.transformer_distance
    in_out = g.transformer_in_out
    push = g.transformer_push
    src = g.transformer_push_source[3 : ]
    time = g.transformer_time
    time_cont = g.transformer_time_control
    se = g.transformer_seed
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    push_loc = Vector((0.0, 0.0, 0.0))
        
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'Out':
            frame = end + start_frame - cur_f
    ok_push = True if obj.get(src) else False   
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)
        if push and ok_push:
             push_loc = obs[i].matrix_world.to_translation() - obj[src].matrix_world.to_translation()
             push_loc -= obs[i].delta_location
        if frame < start:
            trans = s
        elif frame > start + duration_per_ob:
            trans = e
        else:
            trans = transform(frame, start, duration_per_ob, distance, push, push_loc, se, i)
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans


def Shoot(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.shoot_start
    duration_per_ob = g.shoot_duration_per_ob
    duration_offset = g.shoot_duration_offset
    source = g.shoot_source[3 : ]    
    shoot_ease = g.shoot_ease
    in_out = g.shoot_in_out
    time = g.shoot_time
    time_cont = g.shoot_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'Out':
            frame = end + start_frame - cur_f
    if obj.get(source):
        source_loc = obj[source].matrix_world.to_translation()
        for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
            start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)
            if frame < start:
                trans = s
            elif frame > start + duration_per_ob:
                trans = e
            else:
                trans = shoot(frame, start, duration_per_ob, source_loc, obs[i].name, shoot_ease, i)
            obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans

def Explode(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.explode_start
    duration_per_ob = g.explode_duration_per_ob
    duration_offset = g.explode_duration_offset                    
    velocity = g.explode_velocity                 
    ran = g.explode_random              
    gravity = g.explode_gravity                  
    rot = g.explode_rotation
    in_out = g.explode_in_out
    up = g.explode_up
    se = g.explode_seed
    time = g.explode_time                    
    time_cont = g.explode_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
                        
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)                        
        if frame < start:
            trans = e
        elif frame > start + duration_per_ob:
            trans = s
        else:
            trans = explode(frame, start, duration_per_ob, velocity, gravity, rot, up, ran, se, i) 
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans

def Sparks(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.sparks_start
    duration_per_ob = g.sparks_duration_per_ob
    duration_offset = g.sparks_duration_offset                    
    distance = g.sparks_distance                 
    distance2 = g.sparks_distance2                
    rotation = g.sparks_rotation               
    se = g.sparks_seed                
    up = g.sparks_up              
    freq = g.sparks_noise_freq             
    in_out = g.sparks_in_out
    time = g.sparks_time                    
    time_cont = g.sparks_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)
        if frame < start:
            trans = e
        elif frame > start + duration_per_ob:
            trans = s
        else:
            trans = sparks(frame, start, duration_per_ob, distance, distance2, rotation, up, freq, se, i)                       
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans

def Sparks_II(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.sparksii_start
    duration_per_ob = g.sparksii_duration_per_ob
    duration_offset = g.sparksii_duration_offset                    
    distance = g.sparksii_distance                 
    distance2 = g.sparksii_distance2                
    se = g.sparksii_seed                
    up = g.sparksii_up              
    in_out = g.sparksii_in_out
    time = g.sparksii_time                    
    time_cont = g.sparksii_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame 
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)
        if frame < start:
            trans = e
        elif frame > start + duration_per_ob:
            trans = s
        else:
            trans = sparksii(frame, start, duration_per_ob, distance, distance2, up, se, i)                       
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans

def Streaks(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.streaks_start
    duration_per_ob = g.streaks_duration_per_ob
    duration_offset = g.streaks_duration_offset                    
    distance = g.streaks_distance                                  
    in_out = g.streaks_in_out
    se = g.streaks_seed
    time = g.streaks_time                    
    time_cont = g.streaks_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame 
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)
        if frame < start:
            trans = e
        elif frame > start + duration_per_ob:
            trans = s
        else:
            trans = streaks(frame, start, duration_per_ob, distance, se, i)                        
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans
    
def Popcorn(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.popcorn_start
    duration_per_ob = g.popcorn_duration_per_ob
    duration_offset = g.popcorn_duration_offset                    
    distance = g.popcorn_distance                                 
    rotation = g.popcorn_rotation                               
    scale = g.popcorn_scale                                 
    in_out = g.popcorn_in_out
    se = g.popcorn_seed
    time = g.popcorn_time                    
    time_cont = g.popcorn_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame 
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)                        
        if frame < start:
            trans = e
        elif frame > start + duration_per_ob:
            trans = s
        else:
            trans = popcorn(frame, start, duration_per_ob, distance, rotation, scale, se, i)                                                      
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans

def Smooth(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.smooth_start
    duration_per_ob = g.smooth_duration_per_ob
    duration_offset = g.smooth_duration_offset
    distance = g.smooth_distance
    rotation = g.smooth_rotation
    se = g.smooth_seed                    
    in_out = g.smooth_in_out
    time = g.smooth_time                    
    time_cont = g.smooth_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)                        
        if frame < start:
            trans = e
        elif frame > start + duration_per_ob:
            trans = s
        else:
            trans = smooth(frame, start, duration_per_ob, distance, rotation, se, i)
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans

def Butterflies(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.butterfly_start
    duration_per_ob = g.butterfly_duration_per_ob
    duration_offset = g.butterfly_duration_offset
    distance = g.butterfly_distance
    vibration = g.butterfly_vibration
    angle = g.butterfly_vibration_angle
    se = g.butterfly_seed                    
    in_out = g.butterfly_in_out
    time = g.butterfly_time                    
    time_cont = g.butterfly_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)                        
        if frame < start:
            trans = e
        elif frame > start + duration_per_ob:
            trans = s
        else:
            trans = butterflies(frame, start, duration_per_ob, distance, vibration, angle, se, i)                        
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans

def Spiral(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.spiral_start
    duration_per_ob = g.spiral_duration_per_ob
    duration_offset = g.spiral_duration_offset
    turns = g.spiral_turns
    distance = g.spiral_distance
    offset = g.spiral_offset
    in_out = g.spiral_in_out
    se = g.spiral_seed
    up = g.spiral_up
    time = g.spiral_time                    
    time_cont = g.spiral_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)                        
        if frame < start:
            trans = e
        elif frame > start + duration_per_ob:
            trans = s
        else:
            trans = spiral(frame, start, duration_per_ob, distance, offset, turns, up, se, i)
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans

def Smooth_II(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.smoothii_start
    duration_per_ob = g.smoothii_duration_per_ob
    duration_offset = g.smoothii_duration_offset
    turns = g.smoothii_turns
    distance = g.smoothii_distance
    rotation = g.smoothii_rotation
    in_out = g.smoothii_in_out
    se = g.smoothii_seed
    time = g.smoothii_time                    
    time_cont = g.smoothii_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)                        
        if frame < start:
            trans = e
        elif frame > start + duration_per_ob:
            trans = s
        else:
            trans = smoothii(frame, start, duration_per_ob, distance, rotation, turns, se, i)
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans

def Wiggle(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.wiggle_start
    duration_per_ob = g.wiggle_duration_per_ob
    duration_offset = g.wiggle_duration_offset
    comp = g.wiggle_comp
    dist = g.wiggle_distortion
    distance = g.wiggle_distance
    rotation = g.wiggle_rotation
    in_out = g.wiggle_in_out
    se = g.wiggle_seed
    time = g.wiggle_time                    
    time_cont = g.wiggle_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)                        
        if frame < start:
            trans = e
        elif frame > start + duration_per_ob:
            trans = s
        else:
            trans = wiggle(frame, start, duration_per_ob, distance, rotation, comp, dist, se, i)
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans

def Zigzag(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.zigzag_start
    duration_per_ob = g.zigzag_duration_per_ob
    duration_offset = g.zigzag_duration_offset                        
    distance = g.zigzag_distance
    rotation = g.zigzag_rotation
    in_out = g.zigzag_in_out
    se = g.zigzag_seed
    time = g.zigzag_time                    
    time_cont = g.zigzag_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'Out':
            frame = end + start_frame - cur_f
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)                        
        if frame < start:
            trans = s
        elif frame > start + duration_per_ob:
            trans = e
        else:
            trans = zigzag(frame, start, duration_per_ob, distance, rotation, se, i)
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans
        
def Rain(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.rain_start
    duration_per_ob = g.rain_duration_per_ob
    duration_offset = g.rain_duration_offset                    
    distance = g.rain_distance                            
    length = g.rain_length
    in_out = g.rain_in_out
    up = g.rain_up
    time = g.rain_time                    
    time_cont = g.rain_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame 
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)
        if frame < start:
            trans = e
        elif frame > start + duration_per_ob:
            trans = s
        else:
            trans = rain(frame, start, duration_per_ob, distance, length, up, i)                        
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans
        
def Collapse(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.collapse_start
    duration_per_ob = g.collapse_duration_per_ob
    duration_offset = g.collapse_duration_offset
    floor = g.collapse_floor
    s_scale = g.collapse_scale
    rotation = g.collapse_rotation
    spread = g.collapse_spread
    f_axis = g.collapse_axis
    se = g.collapse_seed
    in_out = g.collapse_in_out
    time = g.collapse_time
    time_cont = g.collapse_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)
        own = obs[i].matrix_world.to_translation().z - obs[i].delta_location.z
        if f_axis == 'Y':
            own = obs[i].matrix_world.to_translation().y - obs[i].delta_location.y
        elif f_axis == 'X':
            own = obs[i].matrix_world.to_translation().x - obs[i].delta_location.x
        flr = floor - own        
        if frame < start:
            trans = e
        else:
            trans = collapse(frame, start, duration_per_ob, flr, s_scale, rotation, spread, f_axis, se, i)
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans
        
def Elastic(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.elastic_start
    duration_per_ob = g.elastic_duration_per_ob
    duration_offset = g.elastic_duration_offset
    loc = g.elastic_location
    rot = g.elastic_rotation
    s_start = g.elastic_scale_start
    s_amp = g.elastic_scale_amplitude
    elasticity = g.elastic_elasticity
    slow = g.elastic_slowdown
    in_out = g.elastic_in_out
    time = g.elastic_time
    time_cont = g.elastic_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)
        if frame < start:
            trans = e
        else:            
            trans = elastic(frame, start, duration_per_ob, loc, rot, s_start, s_amp, elasticity, slow, i)
        obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans        

def Copy_animation(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.copy_start
    source = g.copy_source[3 : ]    
    fcs, indexs, rang, starts = avail_fcurves(source)
    duration_per_ob = rang
    duration_offset = g.copy_duration_offset
    local_rot = g.copy_local_rot
    in_out = g.copy_in_out
    time = g.copy_time                    
    time_cont = g.copy_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'Out':
            frame = end + start_frame - cur_f
    if obj.get(source) != None:                        
        for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
            start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)
            if not local_rot:
                obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = \
                copy_animation(frame, start, duration_per_ob, source)
            else:
                trans =  copy_animation(frame, start, duration_per_ob, source)
                l_rot = world_to_local_rot(obs[i], trans[1])
                obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = \
                (trans[0], l_rot, trans[2])
            
def Follow_Curve(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.follow_start
    duration_per_ob = g.follow_duration_per_ob
    duration_offset = g.follow_duration_offset                        
    in_out = g.follow_in_out
    scale = g.follow_scale
    rotation = g.follow_rotation
    source = g.follow_curve[3 : ]    
    nois = g.follow_noise
    nois_freq = g.follow_noise_freq
    se = g.follow_seed
    time = g.follow_time                    
    time_cont = g.follow_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    if obj.get(source):
        points = []
        if obj[source].type == 'CURVE':
            points = get_curve_points(obj[source])
            if len(points) > 0:
                if time_cont:
                    frame = int(time * (duration_per_ob + duration_offset))
                    cur_f = frame
                    start_frame = 0
                else:
                    if in_out == 'In':
                        frame = end + start_frame - cur_f                    
                for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
                    start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)                        
                    if frame < start:
                        trans = e
                    elif frame > start + duration_per_ob:
                        trans = s
                    else:
                        trans = follow(frame, start, duration_per_ob, points, scale, rotation, nois, nois_freq, se, i)
                    obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans
                    
def Custom(scn, g, cur_frame, direction, obs, obj, count, s, e):
    frame = cur_frame
    start_frame = g.custom_start
    duration_per_ob = g.custom_duration_per_ob
    duration_offset = g.custom_duration_offset
    loc = g.custom_location
    rot = g.custom_rotation
    scale = g.custom_scale                    
    loc_ease = g.custom_location_ease
    rot_ease = g.custom_rotation_ease
    scale_ease = g.custom_scale_ease                    
    randomize = g.custom_random
    neg_ran = g.custom_neg
    additive = g.custom_additive
    push = g.custom_push_away
    src = g.custom_push_source[3 : ]
    push_loc = (0.0, 0.0, 0.0)
    local_rot = g.custom_local_rot
    se = g.custom_seed
    in_out = g.custom_in_out
    time = g.custom_time                    
    time_cont = g.custom_time_control
    end = start_frame + duration_per_ob + duration_offset
    cur_f = cur_frame
    if time_cont:
        frame = int(time * (duration_per_ob + duration_offset))
        cur_f = frame
        start_frame = 0
    else:
        if in_out == 'In':
            frame = end + start_frame - cur_f
    ok_push = True if obj.get(src) else False        
    for j, i in enumerate(scn['animax_sorted_colls'][g.name][g.direction]):
        start = get_start_frame(cur_f, j, count, start_frame, duration_offset, direction)
        if push and ok_push:
             push_loc = obs[i].matrix_world.to_translation() - obj[src].matrix_world.to_translation()
             push_loc -= obs[i].delta_location
        if frame < start:
            trans = e
        else:
            trans = custom(frame, start, duration_per_ob, loc, rot, scale, loc_ease, rot_ease, scale_ease, randomize, neg_ran, additive, push, push_loc, se, i)
        if not local_rot:
            obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = trans
        else:
            l_rot = world_to_local_rot(obs[i], trans[1])
            obs[i].delta_location, obs[i].delta_rotation_euler, obs[i].delta_scale = (trans[0], l_rot, trans[2])
    
############################################################################################
################################### Core Functions #########################################
############################################################################################

# Store all the effects in a Dictionary
apply_fx = {'Transformer':Transformer, 'Shoot':Shoot, 'Explode':Explode,
           'Sparks':Sparks, 'Sparks_II':Sparks_II, 'Streaks':Streaks,
           'Popcorn':Popcorn, 'Smooth':Smooth, 'Smooth_II':Smooth_II,
           'Butterflies':Butterflies, 'Spiral':Spiral, 'Wiggle':Wiggle,
           'Zigzag':Zigzag, 'Rain':Rain, 'Collapse':Collapse, 'Elastic':Elastic,
           'Copy_animation': Copy_animation, 'Follow_Curve':Follow_Curve, 'Custom':Custom}
          
# The main function for the animation           
def update_fx(scn):
    obs = []
    cur_frame = scn.frame_current               
    collections = bpy.data.collections
    obj = scn.objects
    s = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)]
    e = [(0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (1.0, 1.0, 1.0)]
    for g in scn.animax_collection.coll:
        if g.name in collections:
            if g.fx_enabled and g.fx != 'None':
                direction = g.direction
                obs = collections[g.name].objects
                count = scn['animax_sorted_colls'][g.name]['Count']                
                if count == len(obs):
                    apply_fx[g.fx](scn, g, cur_frame, direction, obs, obj, count, s, e)           

# Function for updating the effects when the frame changes
@persistent 
def update_animax(scn):
    update_fx(scn)                    

            
############################################################################################
################################### Spliting Utils #########################################
############################################################################################

# Split the objects using particle system and modifiers
def split_using_particles(ob):
    scn = bpy.context.scene
    keep = ob.animax_keep_original
    
    collection_name = get_collection_name(ob.animax_collection_name)
    collection = bpy.data.collections.new(collection_name)
    scn.collection.children.link(collection)
    
    if keep:        
        mesh = ob.data.copy()
        ob = ob.copy()
        ob.data = mesh        
        
    if not ob.name in collection.objects:
        collection.objects.link(ob)
        
    bpy.context.view_layer.objects.active = ob
    for obj in scn.objects:
        obj.select_set(False)
    ob.select_set(True)
            
    scn.frame_current = 1    
    tri = ob.modifiers.new('ANIMAX TRIANGULATE','TRIANGULATE')
    tri.show_viewport = False
    sub = ob.modifiers.new('ANIMAX SUBSURF','SUBSURF')
    sub.levels = 0
    sub.render_levels = 0
    sub.subdivision_type = 'SIMPLE'
    psys_name = 'ANIMAX PARTICLES'
    psys = ob.modifiers.new(psys_name, 'PARTICLE_SYSTEM')
    psystem = ob.particle_systems[0]
    psystem.name = psys_name
    psystem.settings.count = 100
    psystem.settings.frame_start = 1.0
    psystem.settings.frame_end = 1.0
    psystem.settings.physics_type = 'NO'
    psystem.settings.particle_size = 0.9
    psystem.settings.display_method = 'NONE'
    explode = ob.modifiers.new('ANIMAX EXPLODE','EXPLODE') 
    explode.use_size = True
    solid = ob.modifiers.new('ANIMAX SOLIDIFY','SOLIDIFY') 
    solid.show_viewport = False
    ob['ANIMAX SPLIT'] = 'EDIT'
    ob.animax_collection_name = collection_name
    cleanup_collections()
    
# Convert the faces to individual objects
def split_mesh_faces(ob):
    scn = bpy.context.scene
    keep = ob.animax_keep_original
    
    collection_name = get_collection_name(ob.animax_collection_name)
    collection = bpy.data.collections.new(collection_name)
    scn.collection.children.link(collection)
    
    if keep:        
        mesh = ob.data.copy()
        ob = ob.copy()
        ob.data = mesh        
        
    if not ob.name in collection.objects:
        collection.objects.link(ob)
        
    bpy.context.view_layer.objects.active = ob
    for obj in scn.objects:
        obj.select_set(False)
    ob.select_set(True)    
    
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.edge_split()
    bpy.ops.mesh.separate(type='LOOSE')
    bpy.ops.object.mode_set(mode = 'OBJECT')
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
    cleanup_collections()
    
# Separate text letters
def separate_letters(ob1):
    scn = bpy.context.scene
    
    collection_name = get_collection_name(ob1.animax_collection_name)
    collection = bpy.data.collections.new(collection_name)
    scn.collection.children.link(collection)
        
    font = ob1.data.copy()
    ob = ob1.copy()
    ob.data = font    
    
    if not ob.name in collection.objects:
        collection.objects.link(ob)
        
    bpy.context.view_layer.objects.active = ob
    for obj in scn.objects:
        obj.select_set(False)        
    ob.select_set(True)
    
    bpy.ops.object.convert(target='MESH')    
    bpy.ops.object.mode_set(mode = 'EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.remove_doubles()    
    bpy.ops.mesh.separate(type='LOOSE')
    bpy.ops.object.mode_set(mode = 'OBJECT')
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
    cleanup_collections()    
    
    
# Apply the shards (covert to seperate objects)    
def apply_shard(ob):
    for obj in bpy.context.scene.objects:
        if obj != ob:
            obj.select_set(False)
    ob.select_set(True)
    if len(ob.particle_systems) > 0:        
        if 'ANIMAX PARTICLES' in ob.particle_systems:            
            try:
                particles = ob.particle_systems['ANIMAX PARTICLES']
                particles.settings.particle_size = 1.0
                if 'ANIMAX TRIANGULATE' in ob.modifiers:
                    tri = ob.modifiers['ANIMAX TRIANGULATE']
                    if tri.type == 'TRIANGULATE':
                        if not tri.show_viewport:
                            bpy.ops.object.modifier_remove(modifier='ANIMAX TRIANGULATE')
                
                if 'ANIMAX SUBSURF' in ob.modifiers:
                    subsurf = ob.modifiers['ANIMAX SUBSURF']
                    if subsurf.type == 'SUBSURF':
                        if not subsurf.levels > 0:
                            bpy.ops.object.modifier_remove(modifier='ANIMAX SUBSURF')            
                
                if 'ANIMAX SOLIDIFY' in ob.modifiers:
                    solid = ob.modifiers['ANIMAX SOLIDIFY']
                    if solid.type == 'SOLIDIFY':
                        if not solid.show_viewport:
                            bpy.ops.object.modifier_remove(modifier='ANIMAX SOLIDIFY')
                
                if 'ANIMAX EXPLODE' in ob.modifiers:
                    exp = ob.modifiers['ANIMAX EXPLODE']
                    if exp.type == 'EXPLODE':
                        exp.use_size = True
                        
                bpy.ops.object.convert(target='MESH')
        
                        
                        
                bpy.ops.object.modifier_remove(modifier='ANIMAX PARTICLES')        
                bpy.ops.object.mode_set(mode = 'EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.separate(type='LOOSE')
                bpy.ops.object.mode_set(mode = 'OBJECT')
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')                
                
            except Exception as error:
                print(str(error))
            finally:
                cleanup_collections()    

# Cancel the Splitting                
def cancel_splitting(ob):
    scn = bpy.context.scene
    collections = bpy.data.collections
    if ob.animax_keep_original:
        mesh = ob.data
        coll = scn.collection
        if len(ob.users_collection) > 0:
            coll = ob.users_collection[0]       
        
        coll.objects.unlink(ob)
        bpy.data.meshes.remove(mesh)
        
    else: 
        if 'ANIMAX TRIANGULATE' in ob.modifiers:
            bpy.ops.object.modifier_remove(modifier='ANIMAX TRIANGULATE')
        if 'ANIMAX SUBSURF' in ob.modifiers:
            bpy.ops.object.modifier_remove(modifier='ANIMAX SUBSURF')            
        if 'ANIMAX EXPLODE' in ob.modifiers:
            bpy.ops.object.modifier_remove(modifier='ANIMAX EXPLODE')            
        if 'ANIMAX SOLIDIFY' in ob.modifiers:
            bpy.ops.object.modifier_remove(modifier='ANIMAX SOLIDIFY')
        if 'ANIMAX PARTICLES' in ob.modifiers:
            bpy.ops.object.modifier_remove(modifier='ANIMAX PARTICLES')       
        
        if ob.animax_collection_name in collections:
            if collections[ob.animax_collection_name] in ob.users_collection:
                collections[ob.animax_collection_name].objects.unlink(ob)
                
        ob['ANIMAX SPLIT'] = 'NONE'
        ob.animax_keep_original = True
        ob.animax_collection_name = 'ANIMAX'
    cleanup_collections()    
        
                            
    
# Get collection name
def get_collection_name(name = 'ANIMAX'):
    if not bpy.data.collections.get(name):
        return name
    i = 1
    while bpy.data.collections.get(name + str(i)):
        i += 1
    return name + str(i)

# Cleanup the collections
def cleanup_collections():
    collections = bpy.data.collections
    for collection in collections:
        if len(collection.objects) == 0:
            collections.remove(collection)


# Confirm that all the objects are of the type MESH
def are_meshes(obs):    
    for ob in obs:
        if ob.type != 'MESH':
            return False
    return True    
    

############################################################################################
###################################### Operators ###########################################
############################################################################################

######################################### Animation ########################################

# Add all available collections
class ANIMAX_OT_add_collections(Operator):
    bl_idname = "animax.add_available_collections"
    bl_label = "Add all collections"
    bl_description = "Add all the available collections to the ANIMAX list"
    
    def execute(self, context):
        add_all_collections()                                                           
        return {'FINISHED'} 
    
# Delete selected collection
class ANIMAX_OT_delete_collection(Operator):
    bl_idname = "animax.delete"
    bl_label = "Delete"
    bl_description = "Delete the selected collection"
    
    def execute(self, context):
        delete()
        return {'FINISHED'}
    
# Delete all the collections
class ANIMAX_OT_delete_collections(Operator):
    bl_idname = "animax.delete_all"
    bl_label = "Delete all"
    bl_description = "Delete all the collections from the list"
    
    def execute(self, context):
        delete(all = True)
        return {'FINISHED'}  
    
# Enable all the collections
class ANIMAX_OT_enable_collections(Operator):
    bl_idname = "animax.enable_all"
    bl_label = "Enable all"
    bl_description = "Enable all the collections"
    
    def execute(self, context):
        enable_collections(type = 'Enable')
        return {'FINISHED'}
    
# Disable all the collections
class ANIMAX_OT_disable_collections(Operator):
    bl_idname = "animax.disable_all"
    bl_label = "Disable all"
    bl_description = "Disable all the collections"
    
    def execute(self, context):
        enable_collections(type = 'Disable')
        return {'FINISHED'}
    
# Solo selected collection
class ANIMAX_OT_solo_selected_collection(Operator):
    bl_idname = "animax.solo_selected"
    bl_label = "Solo selected"
    bl_description = "Solo selected collection"
    
    def execute(self, context):
        enable_collections(type = 'Solo')
        return {'FINISHED'} 
    
# Select collection's objects
class ANIMAX_OT_select_collection_objects(Operator):
    bl_idname = "animax.select_objects"
    bl_label = "Select"
    bl_description = "Select the collection's objects (Hold Shift to deselect)"
    collection_name : StringProperty()
    
    def invoke(self, context, event):
        collections = bpy.data.collections
        if self.collection_name in collections:
            for ob in collections[self.collection_name].objects:
                ob.select_set(False) if event.shift else ob.select_set(True)
        return {'FINISHED'} 
    
# Clear Delta transform
class ANIMAX_OT_clear_collection_deltas(Operator):
    bl_idname = "animax.clear_delta"
    bl_label = "Clear Delta transform"
    bl_description = "Clear Delta"    
    
    def execute(self, context):
        coll, index = get_animax_collection()
        if len(coll) > 0:
            clear_delta(coll[index].name)
        return {'FINISHED'}
    
# Clear Delta transform for all the collections
class ANIMAX_OT_clear_collections_deltas(Operator):
    bl_idname = "animax.clear_all_delta"
    bl_label = "Clear All Deltas"
    bl_description = "Clear Delta transform for all the collections"
        
    def execute(self, context):
        coll, index = get_animax_collection()
        if len(coll) > 0:
            for i in range(len(coll)):
                clear_delta(coll[i].name)
        return {'FINISHED'}    
    
    
# Sort the objects of a collection according to their location (all the directions)
class ANIMAX_OT_sort_objects(Operator):
    bl_idname = "animax.sort_objects"
    bl_label = "Sort"
    bl_description = "Sort the objects of a collection according to their location in the World space"
    
    def execute(self, context):
        scn = context.scene
        coll, index = get_animax_collection()        
        if len(coll) >0:
            if coll[index].name in bpy.data.collections:
                collection = coll[index].name                
                x,y,z,cur,cus,neg_x,neg_y,neg_z,neg_cur,neg_cus,ran,count = sort_objects(collection)
                dictionary = {
                          'X':x,'Y':y,'Z':z, 'Cursor':cur,'Custom':cus,
                          '-X':neg_x,'-Y':neg_y,'-Z':neg_z,'-Cursor':neg_cur,'-Custom':neg_cus,
                          'Random':ran,'Count':count
                          }            
                scn['animax_sorted_colls'][collection] = dictionary
        return {'FINISHED'}
    
# Sort the objects of a collection according to their location (single direction)
class ANIMAX_OT_sort_single_direction(Operator):
    bl_idname = "animax.sort_direction"
    bl_label = "Sort"
    bl_description = "Sort again the selected direction only (XYZ are sorted together)"
    
    def execute(self, context):
        scn = context.scene
        coll, index = get_animax_collection()        
        if len(coll) >0:
            if coll[index].name in bpy.data.collections:
                collection = coll[index].name
                direction = coll[index].direction
                se = coll[index].random_seed
                if direction in ['X', 'Y', 'Z', '-X', '-Y', '-Z']:
                    x,y,z,neg_x,neg_y,neg_z = sort_objects(collection, 'xyz')
                    scn['animax_sorted_colls'][collection]['X'] = x
                    scn['animax_sorted_colls'][collection]['-X'] = neg_x
                    scn['animax_sorted_colls'][collection]['Y'] = y
                    scn['animax_sorted_colls'][collection]['-Y'] = neg_y
                    scn['animax_sorted_colls'][collection]['Z'] = z
                    scn['animax_sorted_colls'][collection]['-Z'] = neg_z
                elif direction in ['Cursor', '-Cursor']:
                    cur, neg_cur = sort_objects(collection, 'cursor')
                    scn['animax_sorted_colls'][collection]['Cursor'] = cur
                    scn['animax_sorted_colls'][collection]['-Cursor'] = neg_cur
                elif direction in ['Custom', '-Custom']:
                    cus, neg_cus = sort_objects(collection, 'custom')
                    scn['animax_sorted_colls'][collection]['Custom'] = cus
                    scn['animax_sorted_colls'][collection]['-Custom'] = neg_cus
                elif direction == 'Random':
                    ran = sort_objects(collection, 'random', se)
                    scn['animax_sorted_colls'][collection]['Random'] = ran
                                            
        return {'FINISHED'}    

    
# Bake to keyframes
class ANIMAX_OT_bake_to_keyframes(Operator):
    bl_idname = "animax.bake"
    bl_label = "Bake To KeyFrames"
    bl_description = "Bake the selected collection to keyframes"  
    
    
    start : IntProperty(default = 1, min = 0, max = 1000000, description = 'Start frame for baking')
    end : IntProperty(default = 250, min = 1, max = 1000000, description = 'End frame for baking')
    
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.separator()        
        col.label(text = 'This operation may take a long time !!!', icon = 'INFO')
        col.label(text = '     Make sure to "Save"  before proceeding.')
        col.separator()                
        col.separator()               
        col.prop(self, "start", text = 'Start Frame')
        col.prop(self, "end", text = 'End Frame')
        col.separator()
        
    def execute(self, context):
        coll, index = get_animax_collection()
        collections = bpy.data.collections
        wm = bpy.context.window_manager
        scn = context.scene
        f = scn.frame_current
        if len(coll) > 0:
            name = coll[index].name
            if self.start < self.end:
                if name in collections and name in scn['animax_sorted_colls']:
                    objs = collections[name].objects
                    count = len(objs)
                    if count > 0 and scn['animax_sorted_colls'][name]['Count'] == count:
                        if coll[index].fx_enabled and coll[index].fx != 'None':                            
                            wm.progress_begin(0, 100)
                            s = int(time.time())
                            scn.frame_set(self.start)
                            for i in range(self.start, self.end+1):
                                scn.frame_set(i)
                                for ob in objs:        
                                    ob.keyframe_insert('location')
                                    ob.keyframe_insert('rotation_euler')
                                    ob.keyframe_insert('scale')
                                wm.progress_update(int((i*50)/self.end))                                                             
                            scn.frame_set(self.start)
                            for i in range(self.start, self.end+1):
                                scn.frame_set(i)
                                for ob in objs:
                                    loc, rot, scale = ob.matrix_basis.decompose()                                        
                                    ob.location = loc
                                    ob.rotation_euler = rot.to_euler()
                                    ob.scale= scale
                                    ob.keyframe_insert('location')
                                    ob.keyframe_insert('rotation_euler')
                                    ob.keyframe_insert('scale')
                                wm.progress_update(int((i*50)/self.end) + 50)                                
                            wm.progress_end()
                            e = int(time.time())                            
                            coll[index].fx_enabled = False  
                            clear_delta(name)
                            scn.frame_current = f
                            self.report({'INFO'}, 'Baked successfully in : '+ str(e-s)+' seconds')
                        else:
                            self.report({'WARNING'}, "The effects aren't enabled !")
                    else:
                        self.report({'WARNING'}, "The count of the objects isn't right, or the collection is empty, Sorting the objects may solve this problem")        
                else:
                    self.report({'WARNING'}, "Invalid Gourp, Sorting the objects may solve this problem") 
            else:
                self.report({'WARNING'}, "The End frame must be greater than the Start frame")
        else:
            self.report({'WARNING'}, "Nothing to Bake!")                       
                        
        return {'FINISHED'}
    
    
# Bake to Shapekeys
class ANIMAX_OT_bake_to_shapekeys(Operator):
    bl_idname = "animax.bake_shapes"
    bl_label = "Bake To Shape Keys"
    bl_description = "Bake the selected collection to Shape Keys"  
    
    
    start : IntProperty(default = 1, min = 0, max = 1000000, description = 'Start frame for baking.')
    end : IntProperty(default = 250, min = 1, max = 1000000, description = 'End frame for baking.')    
    apply_mod : BoolProperty(default = False,
                             description = "Apply the modifiers for all the objects. Don't use this option unless you have objects with modifiers, because it will slow down the baking process.")
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.separator()        
        col.label(text = 'This operation may take a long time !!!', icon = 'INFO')
        col.label(text = '     Make sure to "Save"  before proceeding.')
        col.separator()
        col.prop(self, "apply_mod", text = 'Apply the Modifiers')
        col.separator()        
        col.prop(self, "start", text = 'Start Frame')
        col.prop(self, "end", text = 'End Frame')
        col.separator()
        
    def execute(self, context):
        coll, index = get_animax_collection()
        collections = bpy.data.collections
        wm = bpy.context.window_manager
        scn = context.scene
        obs = scn.objects
        f = scn.frame_current
        datas = []
        if len(coll) > 0:
            name = coll[index].name
            collection = collections[name]
            if self.start < self.end:
                if name in collections and name in scn['animax_sorted_colls']:
                    objs = collections[name].objects
                    count = len(objs)
                    if count > 0 and scn['animax_sorted_colls'][name]['Count'] == count:
                        if are_meshes(objs):
                            collection.hide_viewport = False
                            collection_name = get_collection_name(name + ' Baked')
                            new_collection = bpy.data.collections.new(collection_name)
                            scn.collection.children.link(new_collection)
                            wm.progress_begin(0, 100)
                            s = int(time.time())
                            scn.frame_set(self.start)
                            
                            for ob in scn.objects:
                                ob.select_set(False)
                            for ob in objs:    
                                ob.hide_viewport = False
                                
                            for i in range(self.start, self.end+1):
                                scn.frame_set(i)
                                for obj in objs:                                                                        
                                    obj.select_set(True)
                                bpy.ops.object.duplicate(linked = not self.apply_mod)
                                if self.apply_mod:
                                    context.view_layer.objects.active = objs[len(objs)-1]
                                    bpy.ops.object.convert(target='MESH')
                                    
                                datas = [ob.data for ob in context.selected_objects] if self.apply_mod else []
                                new_shape = "shape_" + str(i).zfill(5)
                                new_data = bpy.data.meshes.new(new_shape)
                                new_obj = bpy.data.objects.new(("frame(" + str(i) + ")"), new_data)
                                new_collection.objects.link(new_obj)                                
                                context.view_layer.objects.active = new_obj
                                new_obj.select_set(True)
                                bpy.ops.object.join()                                
                                
                                for ob in context.selected_objects:
                                    ob.select_set(False)
                                new_obj.select_set(True)
                                    
                                if i == self.start:
                                    dest_obj = new_obj            
                                    if hasattr(dest_obj.data.shape_keys, 'key_blocks'):                
                                        for key in dest_obj.data.shape_keys.key_blocks:
                                            dest_obj.shape_key_remove(key)
                                    dest_obj.shape_key_add(name = "Basis", from_mix = False)
                                    dest_obj.select_set(False)
                                else:            
                                    current_shape = new_obj.name
                                    if hasattr(new_obj.data.shape_keys, 'key_blocks'):
                                        for key in new_obj.data.shape_keys.key_blocks:
                                            new_obj.shape_key_remove(key)                
                                    context.view_layer.objects.active = dest_obj
                                    bpy.ops.object.join_shapes()
                                    bpy.data.objects.remove(new_obj)                                    
                                    key_block = dest_obj.data.shape_keys.key_blocks[current_shape]                                    
                                    key_block.value = 0.0
                                    key_block.keyframe_insert("value",frame=i-1)
                                    key_block.value = 1.0
                                    key_block.keyframe_insert("value",frame=i)
                                    if i != self.end:
                                        key_block.value = 0.0
                                        key_block.keyframe_insert("value",frame=i+1)
                                    bpy.data.meshes.remove(bpy.data.meshes[new_shape])
                                    dest_obj.select_set(False)
                                for d in datas:
                                    if not d.users:
                                        bpy.data.meshes.remove(d)    
                                wm.progress_update(int((i-self.start)*100/self.end))                                
                            dest_obj.name = name + '_baked'
                            dest_obj.data.name = name + '_baked'
                            dest_obj.select_set(True)
                            wm.progress_end()
                            e = int(time.time())                            
                            coll[index].fx_enabled = False  
                            clear_delta(name)
                            scn.frame_current = f
                            self.report({'INFO'}, 'Baked successfully in : '+ str(e-s)+' seconds')
                        else:
                            self.report({'WARNING'}, "All the objects must be of the type MESH")
                    else:
                        self.report({'WARNING'}, "The count of the objects isn't right, or the collection is empty, Sorting the objects may solve this problem")        
                else:
                    self.report({'WARNING'}, "Invalid Gourp, Sorting the objects may solve this problem") 
            else:
                self.report({'WARNING'}, "The End frame must be greater than the Start frame")
        else:
            self.report({'WARNING'}, "Nothing to Bake!")                       
                        
        return {'FINISHED'}    

    
    
# Clear all the keyframes
class ANIMAX_OT_free_bake(Operator):
    bl_idname = "animax.clear_kayframes"
    bl_label = "Clear Keyframes"
    bl_description = "Clear All the Keyframes"
        
    def execute(self, context):
        coll, index = get_animax_collection()
        collections = bpy.data.collections
        if len(coll) > 0:
            name = coll[index].name
            if name in collections:
                objs = collections[name].objects
                count = len(objs)
                if count > 0:
                    for ob in objs:
                        ob.animation_data_clear()
                    self.report({'INFO'}, 'Keyframes removed!')
        else: self.report({'WARNING'}, "Nothing to Remove!")            
                
        return {'FINISHED'}
    
# The object picker
class ANIMAX_OT_object_picker(Operator):
    bl_idname = "animax.object_picker"
    bl_label = "Object Picker"
    bl_description = "Set the active object as a Source"
    
    prop : StringProperty()
    collection_name : StringProperty()    
        
    def execute(self, context):
        coll, index = get_animax_collection()
        obs = context.view_layer.objects
        if obs.active:
            ob = obs.active
            if self.prop == 'Shoot':
                coll[self.collection_name].shoot_source = '   ' + ob.name
            elif self.prop == 'Trans':
                coll[self.collection_name].transformer_push_source = '   ' + ob.name
            elif self.prop == 'Custom':
                coll[self.collection_name].custom_push_source = '   ' + ob.name
            elif self.prop == 'Follow' and ob.type == 'CURVE':
                coll[self.collection_name].follow_curve = '   ' + ob.name
            elif self.prop == 'Copy':
                coll[self.collection_name].copy_source = '   ' + ob.name    
        return {'FINISHED'}
    
    
# Get the selection order    
class ANIMAX_OT_get_selection_order(Operator):    
    bl_idname = "animax.get_selection_order"
    bl_label = "Make a custom selection"
    bl_description = "Create a custom order based on the selection order"

    _timer = None    

    def modal(self, context, event):
        if hasattr(context.area, 'tag_redraw'):
            context.area.tag_redraw()
        
        if event.type in {'ESC', 'RET'}:            
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')            
            self.cancel(context)
            return {'CANCELLED'}

        if event.type == 'TIMER':
            scn = context.scene            
            if 'animax_selection' in scn and hasattr(context, 'selected_objects'):
                selected = context.selected_objects
                old_order = scn['animax_selection']    
                old_order = [ob for ob in old_order if scn.objects.get(ob) in selected ]
                new_order = [ob.name for ob in selected if not ob.name in old_order]
                scn['animax_selection'] = old_order + new_order

        return {'PASS_THROUGH'}

    def execute(self, context):
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.05, window = context.window)
        if context.area.type == 'VIEW_3D' and hasattr(context, 'selected_objects'):            
            args = (self, context)           
            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_callback, args, 'WINDOW', 'POST_PIXEL')
            wm.modal_handler_add(self)        
        return {'RUNNING_MODAL'}  
    

    def cancel(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)        
    
########################################## Spliting ########################################
    
# Split the object using Particles system and Modifiers
class ANIMAX_OT_particles_spliting(Operator):
    bl_idname = "animax.particles_spliting"
    bl_label = "Split the object"
    bl_description = "Split the object using Particles system and Modifiers"
        
    def execute(self, context):
        ob = context.object
        split_using_particles(ob)
        return {'FINISHED'}
    
# Apply shards (for Particles based spliting)
class ANIMAX_OT_apply_shards(Operator):
    bl_idname = "animax.apply_shards"
    bl_label = "Apply"
    bl_description = "Convert the shards to objects"
        
    def execute(self, context):
        ob = context.object
        if 'ANIMAX SPLIT' in ob:
            if ob['ANIMAX SPLIT'] == 'EDIT':
                ob['ANIMAX SPLIT'] = 'NONE'
                apply_shard(ob)
        return {'FINISHED'}
    
# Convert the mesh faces to individual objects
class ANIMAX_OT_split_faces(Operator):
    bl_idname = "animax.split_faces"
    bl_label = "Separate the faces"
    bl_description = "Convert the mesh faces to individual objects"
        
    def execute(self, context):
        ob = context.object
        split_mesh_faces(ob)
        return {'FINISHED'} 
    
# Separate the letters
class ANIMAX_OT_separate_letters(Operator):
    bl_idname = "animax.separate_letters"
    bl_label = "Separate the letters"
    bl_description = "Convert the letters to individual objects"
        
    def execute(self, context):
        ob = context.object
        if ob.type == 'FONT':
            separate_letters(ob)
        return {'FINISHED'}       
    
# Cancel the Splitting process
class ANIMAX_OT_cancel_split(Operator):
    bl_idname = "animax.cancel_splitting"
    bl_label = "Cancel"
    bl_description = "Cancel the Splitting process"
        
    def execute(self, context):
        ob = context.object
        cancel_splitting(ob)
        return {'FINISHED'}
    
########################################## Presets ########################################
    
# Save a Preset
class ANIMAX_OT_save_preset(Operator):
    bl_idname = "animax.save_preset"
    bl_label = "Save a New Preset"
    bl_description = "Save the current animation as a preset"
    
    @classmethod
    def poll(cls, context):
        return context.scene.animax_preset_name != ''    
    
        
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):        
        preset = context.scene.animax_preset_name        
        layout = self.layout
        col = layout.column()
        col.separator()        
        col.label(text = 'Add  "'+ preset +'"  to your Presets?', icon = 'QUESTION' )        
        col.separator()        
        
    def execute(self, context):        
        preset = context.scene.animax_preset_name
        preset.replace('.animax', '')
        if preset.strip():
            if are_chars_valid(preset):                
                preset = preset + ".animax"    
                save_preset(preset)
                path = os.path.join(presets_folder, preset)
                if os.path.exists(path):
                    self.report({'INFO'}, preset + ' : Saved Successfully!')
                    context.scene.animax_preset_name = ''            
                else:
                    self.report({'WARNING'}, 'Something Went Wrong!')
            else:
                self.report({'WARNING'}, 'Char(s), not valid.')
                        
        else:
            self.report({'WARNING'}, 'Invalid name.')
            
        return {'FINISHED'}
    
# Load a Preset
class ANIMAX_OT_load_preset(Operator):
    bl_idname = "animax.load_preset"
    bl_label = "Load"
    bl_description = "Load the the selected Preset"
    
    @classmethod
    def poll(cls, context):
        return context.scene.animax_presets != '_Empty_'
    
    def execute(self, context):
        load_preset()        
        return {'FINISHED'}
    
# Delete a Preset
class ANIMAX_OT_delete_preset(Operator):
    bl_idname = "animax.delete_preset"
    bl_label = "Delete"
    bl_description = "Delete the selected Preset"
    
    @classmethod
    def poll(cls, context):
        return context.scene.animax_presets != '_Empty_'
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):        
        preset = context.scene.animax_presets
        layout = self.layout
        col = layout.column()
        col.separator()
        col.label(text = 'Delete  "'+ preset +'"  from your Presets?', icon = 'QUESTION' )        
        col.separator()
    
    def execute(self, context):
        delete_preset()    
        return {'FINISHED'}
    
# Rename a Preset
class ANIMAX_OT_rename_preset(Operator):
    bl_idname = "animax.rename_preset"
    bl_label = "Rename"
    bl_description = "Rename the selected Preset"    
    
    name : StringProperty(default = '', description = 'The new Name')
    
    @classmethod
    def poll(cls, context):
        return context.scene.animax_presets != '_Empty_'
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):        
        layout = self.layout
        col = layout.column()        
        col.separator()
        col.prop(self, 'name', text = 'New Name')
        col.separator()
    
    def execute(self, context):
        if self.name.strip():
            if self.name not in get_presets_list():
                if are_chars_valid(self.name):
                    new_name = self.name + '.animax'
                    rename_preset(new_name)
                else:
                    self.report({'WARNING'}, 'Char(s), not valid.')                        
            else:
                self.report({'WARNING'}, 'The Preset: "' + self.name + '" Already exists.')
        else:
            self.report({'WARNING'}, 'Invalid name.')        
        return {'FINISHED'}                
    
############################################################################################
############################ Property Group for the UI list#################################
############################################################################################

class Animax(PropertyGroup):    
    name : StringProperty(update = update_prop_name, description = 'The name of the collection')
    name_originale : StringProperty()
    fx_enabled : BoolProperty(default = False, update = update_time_props, description = 'Enable/Disable the effects for this collection.')    
    direction : EnumProperty(name = 'Direction',
                             items = (('X','X',''),('-X','-X',''), ('Y','Y',''),
                                      ('-Y','-Y',''), ('Z','Z',''), ('-Z','-Z',''),
                                      ('Cursor', 'Cursor', ''), ('-Cursor', '-Cursor', ''),
                                      ('Custom', 'Custom', ''), ('-Custom', '-Custom', ''),
                                      ('Random','Random','')),
                             default = 'Random',
                             description = 'The direction of the offset.',
                             update = update_time_props)    
    fx : EnumProperty(name = 'Effects', items = effects, update = update_time_props,
                      description = 'The Effects')
    random_seed : IntProperty(default = 0, min = 0, max = 1000000, description = 'Random seed for the Direction')
    
    # Transformer parameters                  
    transformer_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                                    description = 'First frame of the animation.')                                    
    transformer_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                              description = 'The duration of the effect on a single object')                                                  
    transformer_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                              description = 'The duration of offset')    
    transformer_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                                   description = 'Random seed')
    transformer_distance : FloatProperty(default = 1.0, min = 0.01, max = 100.0, update = update_props,
                                         description = 'The distance between the initial and final location')
    transformer_push : BoolProperty(default = False, update = update_props, description = 'Push the objects away from a source object')
    transformer_push_source : StringProperty(update = update_props, description = 'Push the objects away from this object')                                                 
    transformer_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                      description = 'Transition type')
    transformer_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    transformer_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')
    
    # Shoot parameters
    shoot_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                              description = 'First frame of the animation')
    shoot_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                        description = 'The duration of the effect on a single object')       
    shoot_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                        description = 'The duration of offset')    
    shoot_source : StringProperty(update = update_props, description = 'The source object (Emitter)')
    shoot_ease : EnumProperty(name = 'Easing', items = easing_list, description = 'Easing', update = update_props)
    shoot_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                description = 'Transition type.')       
    shoot_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    shoot_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')
    
    # Explode parameters
    explode_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                                description = 'First frame of the animation')
    explode_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                          description = 'The duration of the effect on a single object')       
    explode_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                          description = 'The duration of offset')    
    explode_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                  description = 'Transition type')
    explode_up : EnumProperty(name = 'Up axis', items = (('Z','Z',''),('Y','Y','')), default = 'Z', update = update_props,
                              description = 'The Up Axis')
    explode_velocity :  FloatVectorProperty(subtype = 'XYZ', default = (5.0, 5.0, 10.0), update = update_props,
                                            description = 'Initial Velocity')
    explode_random :  BoolVectorProperty(default = (1, 1 ,1), update = update_props,
                                         description = 'Randomize the initial Velocity')
    explode_rotation : FloatProperty(default = 2*pi, min = 0.0, max = pi*100, subtype =  'ANGLE', update = update_props,
                                     description = 'Final rotation (Initial = (0,0,0))')            
    explode_gravity : FloatProperty(default = 10.0, min = 0.0, max = 10000.0, update = update_props,
                                    description = 'The gravity')
    explode_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                               description = 'Random seed')
    explode_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    explode_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')                           
    
    # Sparks parameters
    sparks_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                               description = 'First frame of the animation')
    sparks_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                         description = 'The duration of the effect on a single object')       
    sparks_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                         description = 'The duration of offset')    
    sparks_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                 description = 'Transition type')
    sparks_distance : FloatProperty(default = 5.0, min = 0.0, max = 10000.0, update = update_props,
                                    description = 'The distance between the initial and final Verticale location')            
    sparks_distance2 : FloatProperty(default = 5.0, min = 0.0, max = 10000.0, update = update_props,
                                     description = 'The distance between the initial and final Horizontal location')
    sparks_rotation : FloatProperty(default = pi, min = 0.0, max = 100*pi, subtype =  'ANGLE', update = update_props,
                                    description = 'Final rotation (Initial = (0,0,0))')                                 
    sparks_up : EnumProperty(name = 'Up axis', items = (('Z','Z',''),('Y','Y','')), default = 'Z', update = update_props,
                             description = 'The Up Axis')
    sparks_noise_freq : FloatProperty(default = 1.0, min = -10000.0, max = 10000.0, update = update_props,
                                description = 'The noise frequency')                         
    sparks_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                              description = 'Random seed')
    sparks_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    sparks_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')
    
    # Sparks-II parameters
    sparksii_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                               description = 'First frame of the animation')
    sparksii_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                         description = 'The duration of the effect on a single object')       
    sparksii_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                         description = 'The duration of offset')    
    sparksii_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                 description = 'Transition type')
    sparksii_distance : FloatProperty(default = 5.0, min = 0.0, max = 10000.0, update = update_props,
                                    description = 'The distance between the initial and final Verticale location')            
    sparksii_distance2 : FloatProperty(default = 2.0, min = 0.0, max = 10000.0, update = update_props,
                                     description = 'The distance between the initial and final Horizontal location')
    sparksii_up : EnumProperty(name = 'Up axis', items = (('Z','Z',''),('Y','Y','')), default = 'Z', update = update_props,
                             description = 'The Up Axis') 
    sparksii_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                              description = 'Random seed')
    sparksii_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    sparksii_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')
    
    # Streaks parameters
    streaks_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                                description = 'First frame of the animation')
    streaks_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                          description = 'The duration of the effect on a single object')       
    streaks_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                          description = 'The duration of offset')    
    streaks_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                  description = 'Transition type')
    streaks_distance : FloatProperty(default = 5.0, min = 0.01, max = 10000.0, update = update_props,
                                     description = 'The maximum length of the streaks')
    streaks_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                               description = 'Random seed')
    streaks_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    streaks_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')                           
    
    # Popcorn parameters
    popcorn_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                                description = 'First frame of the animation')
    popcorn_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                          description = 'The duration of the effect on a single object')       
    popcorn_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                          description = 'The duration of offset')
    popcorn_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                  description = 'Transition type')
    popcorn_scale : FloatProperty(default = 1.0, min = 0.0, max = 10000.0, update = update_props,
                                  description = 'The maximum scale of the objects')
    popcorn_distance : FloatProperty(default = 1.0, min = 0.0, max = 10000.0, update = update_props,
                                     description = 'The distance between the initial and final location')
    popcorn_rotation : FloatProperty(default = pi, min = 0.0, max = 40*pi, subtype =  'ANGLE', update = update_props,
                                     description = 'Final rotation (Initial = (0,0,0))')
    popcorn_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                               description = 'Random seed')
    popcorn_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    popcorn_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')
    
    # Smooth parameters
    smooth_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                               description = 'First frame of the animation')
    smooth_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                         description = 'The duration of the effect on a single object')       
    smooth_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                         description = 'The duration of offset')    
    smooth_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                 description = 'Transition type')
    smooth_distance : FloatProperty(default = 5.0, min = 0.0, max = 10000.0, update = update_props,
                                    description = 'The distance between the initial and final location')            
    smooth_rotation : FloatProperty(default = pi, min = 0.0, max = 2*pi, subtype =  'ANGLE', update = update_props,
                                    description = 'Final rotation (Initial = (0,0,0))')
    smooth_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                              description = 'Random seed')
    smooth_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    smooth_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')                          
    
    # Butterflies parameters
    butterfly_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                                  description = 'First frame of the animation')
    butterfly_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                            description = 'The duration of the effect on a single object')       
    butterfly_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                            description = 'The duration of offset')    
    butterfly_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                    description = 'Transition type')
    butterfly_distance : FloatProperty(default = 5.0, min = 0.0, max = 10000.0, update = update_props,
                                       description = 'The distance between the initial and final location')            
    butterfly_vibration_angle : FloatProperty(default = 2*pi, min = 0.0, max = 2*pi, subtype =  'ANGLE', update = update_props,
                                              description = 'Vibration angle')
    butterfly_vibration : IntProperty(default = 10, min = 1, max = 10, update = update_props,
                                      description = 'How much vibration.')
    butterfly_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                                 description = 'Random seed')
    butterfly_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    butterfly_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')                             
    
    # Spiral parameters
    spiral_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                               description = 'First frame of the animation')
    spiral_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                         description = 'The duration of the effect on a single object')       
    spiral_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                         description = 'The duration of offset')    
    spiral_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                 description = 'Transition type')
    spiral_distance : FloatProperty(default = 5.0, min = -10000, max = 10000.0, update = update_props,
                                    description = 'The distance between the initial and final location')
    spiral_offset : FloatProperty(default = 0.0, min = -10000, max = 10000.0, update = update_props,
                                    description = 'The vertical distance')                                
    spiral_turns : IntProperty(name = 'Number of turns', default = 1, min = 1, max = 100, update = update_props,
                               description = 'The number of turns')
    spiral_up : EnumProperty(name = 'Up axis', items = (('X','X',''),('Y','Y',''),('Z','Z',''),('Random','Random','')), default = 'Z', update = update_props,
                             description = 'The up axis')
    spiral_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                              description = 'Random seed')
    spiral_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    spiral_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')                          
    
    # Smooth II parameters
    smoothii_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                                 description = 'First frame of the animation')
    smoothii_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                           description = 'The duration of the effect on a single object')       
    smoothii_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                           description = 'The duration of offset')    
    smoothii_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                   description = 'Transition type')
    smoothii_distance : FloatProperty(default = 5.0, min = -10000, max = 10000.0, update = update_props,
                                      description = 'The distance between the initial and final location')
    smoothii_rotation : FloatProperty(default = pi, min = 0.0, max = 10*pi, subtype =  'ANGLE', update = update_props,
                                      description = 'Final rotation (Initial = (0,0,0))')
    smoothii_turns : IntProperty(name = 'Number of turns', default = 2, min = 1, max = 100, update = update_props,
                                 description = 'The number of turns')    
    smoothii_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                                description = 'Random seed')
    smoothii_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    smoothii_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')                            
    
    # Wiggle parameters
    wiggle_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                               description = 'First frame of the animation')
    wiggle_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                         description = 'The duration of the effect on a single object')       
    wiggle_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                         description = 'The duration of offset')    
    wiggle_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                 description = 'Transition type')
    wiggle_distance : FloatProperty(default = 5.0, min = -10000.0, max = 10000.0, update = update_props,
                                    description = 'The distance between the initial and final location')
    wiggle_rotation : FloatProperty(default = pi, min = 0.0, max = 100*pi, subtype =  'ANGLE', update = update_props,
                                    description = 'Final rotation (Initial = (0,0,0))')
    wiggle_comp : FloatProperty(default = 1.0, min = 0.0, max = 100.0, update = update_props,
                                description = 'The complexity of the movement (The frequency)')
    wiggle_distortion : FloatProperty(default = 0.5, min = 0.0, max = 50.0, update = update_props,
                                      description = 'A second layer of complexity (Noise)')    
    wiggle_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                              description = 'Random seed')
    wiggle_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    wiggle_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')
    
    # Zigzag parameters
    zigzag_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                               description = 'First frame of the animation')
    zigzag_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                         description = 'The duration of the effect on a single object')       
    zigzag_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                         description = 'The duration of offset')    
    zigzag_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                 description = 'Transition type')
    zigzag_distance : FloatProperty(default = 5.0, min = -10000.0, max = 10000.0, update = update_props,
                                    description = 'The distance between the initial and final location')
    zigzag_rotation : FloatProperty(default = pi, min = 0.0, max = 100*pi, subtype =  'ANGLE', update = update_props,
                                    description = 'Final rotation (Initial = (0,0,0))')        
    zigzag_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                              description = 'Random seed')
    zigzag_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    zigzag_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')
    
    # Rain parameters
    rain_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                               description = 'First frame of the animation')
    rain_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                         description = 'The duration of the effect on a single object')       
    rain_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                         description = 'The duration of offset')    
    rain_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                 description = 'Transition type')
    rain_distance : FloatProperty(default = 5.0, min = 0.0, max = 10000.0, update = update_props,
                                    description = 'The distance between the initial and final location')
    rain_up : EnumProperty(name = 'Up axis', items = (('Z','Z',''),('Y','Y','')), default = 'Z', update = update_props,
                             description = 'The Up Axis')
    rain_length : FloatProperty(default = 5.0, min = 0.01, max = 10000.0, update = update_props,
                                     description = 'The maximum length of the Rain drops')
    rain_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    rain_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')
    
    # Collapse parameters
    collapse_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                              description = 'First frame of the animation')
    collapse_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                        description = 'The duration of the effect on a single object')       
    collapse_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                        description = 'The duration of offset')    
    collapse_floor : FloatProperty(default = -1.0, min = -10000.0, max = 10000.0, update = update_props, description = 'Floor distance')
    collapse_spread : FloatProperty(default = 0.0, min = -10000.0, max = 10000.0, update = update_props, description = 'Random distribution')
    collapse_scale : BoolProperty(default = False, update = update_props, description = 'Initial scale = 0.0')
    collapse_rotation : FloatVectorProperty(name = 'Rotation', subtype = 'EULER', update = update_props,
                                          description = 'The initial rotation')
    collapse_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                              description = 'Random seed')
    collapse_axis : EnumProperty(name = 'Floor axis', items = (('X','X',''),('Y','Y',''),('Z','Z','')), default = 'Z', update = update_props,
                             description = 'The Floor axis')                          
    collapse_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                description = 'Transition type')       
    collapse_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    collapse_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')
    
    # Elastic parameters
    elastic_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                              description = 'First frame of the animation')
    elastic_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                        description = 'The duration of the effect on a single object')       
    elastic_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                        description = 'The duration of offset')
    elastic_location : FloatVectorProperty(name = 'Location', subtype = 'XYZ', update = update_props,
                                          description = 'The initial location')
    elastic_rotation : FloatVectorProperty(name = 'Rotation', subtype = 'EULER', update = update_props,
                                          description = 'The initial rotation')                                      
    elastic_elasticity : IntVectorProperty(name = 'Elasticity', default = (2, 2, 2), min = 1, max = 100, update = update_props,
                               description = 'Elasticity')
    elastic_slowdown : IntVectorProperty(name = 'Slow down', default = (1, 1, 1), min = 1, max = 25, update = update_props,
                               description = 'Slow down')
    elastic_scale_start : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_props, description = 'The initial Scale')                           
    elastic_scale_amplitude : FloatProperty(default = 1.0, min = 1.0, max = 1000.0, update = update_props, description = 'The amplitude')                           
    elastic_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                description = 'Transition type')       
    elastic_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    elastic_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')
    
    # Copy animation parameters
    copy_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                             description = 'First frame of the animation')        
    copy_duration_offset : IntProperty(default = 48, min = 1, max = 1000, update = update_props,
                                       description = 'The duration of offset')    
    copy_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                               description = 'Transition type')
    copy_source : StringProperty(update = update_props, description = 'Copy the animation of this object, (Loc, Rot, Scale)') 
    copy_local_rot : BoolProperty(default = False, update = update_props, description = 'Rotate the objects along their local axis')
    copy_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    copy_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')
    
    # Follow parameters
    follow_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                               description = 'First frame of the animation')
    follow_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                         description = 'The duration of the effect on a single object')       
    follow_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                         description = 'The duration of offset')    
    follow_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                 description = 'Transition type')   
    follow_curve :StringProperty(update = update_props, description = 'The Curve to follow')
    follow_scale : FloatProperty(default = 1.0, min = 0.0, max = 10000.0, update = update_props,
                                description = 'The scale of the curve')
    follow_rotation : FloatProperty(default = 0.0, min = 0.0, max = 100*pi, subtype =  'ANGLE', update = update_props,
                                      description = 'Final rotation (Initial = (0,0,0))')                            
    follow_noise : FloatProperty(default = 0.0, min = 0.0, max = 100.0, update = update_props,
                                description = 'Add some randomness')
    follow_noise_freq : FloatProperty(default = 1.0, min = -10000.0, max = 10000.0, update = update_props,
                                description = 'The noise frequency')
    follow_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props,
                              description = 'Random seed')
    follow_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    follow_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')                          
    
    # Custom parameters
    custom_start : IntProperty(default = 1, min = 0, max = 1000000, update = update_time_props,
                               description = 'First frame of the animation')
    custom_duration_per_ob : IntProperty(default = 48, min = 5, max = 1000, update = update_props,
                                         description = 'The duration of the effect on a single object')       
    custom_duration_offset : IntProperty(default = 48, min = 0, max = 1000, update = update_props,
                                         description = 'The duration of offset')    
    custom_in_out : EnumProperty(name = 'In/Out', items = (('In','In',''),('Out','Out','')), default = 'In', update = update_time_props,
                                 description = 'Transition type')
    custom_location : FloatVectorProperty(name = 'Location', subtype = 'XYZ', update = update_props,
                                          description = 'The initial location')
    custom_rotation : FloatVectorProperty(name = 'Rotation', subtype = 'EULER', update = update_props,
                                          description = 'The initial rotation')
    custom_scale : FloatVectorProperty(name = 'Scale', default = (1.0, 1.0, 1.0), subtype = 'XYZ', update = update_props,
                                       description = 'The initial scale')
    custom_location_ease : EnumProperty(name = 'Easing', items = easing_list, description = 'Easing', update = update_props)
    custom_rotation_ease : EnumProperty(name = 'Easing', items = easing_list, description = 'Easing', update = update_props)
    custom_scale_ease : EnumProperty(name = 'Easing', items = easing_list, description = 'Easing', update = update_props)
    custom_random : FloatVectorProperty(name = 'Random', min = 0.0, max = 1.0, update = update_props, description = 'Randomize')    
    custom_expand_loc : BoolProperty(default = True, update = update_props, description = 'Expand/collapse this menu')
    custom_expand_rot : BoolProperty(default = True, update = update_props, description = 'Expand/collapse this menu')
    custom_expand_scale : BoolProperty(default = True, update = update_props, description = 'Expand/collapse this menu')
    custom_neg : BoolVectorProperty(default = (1, 1 ,1), update = update_props, description = 'Include negative numbers')
    custom_additive : BoolVectorProperty(default = (1, 1, 0), update = update_props, description = 'Add the random value to the initial value')
    custom_push_away : BoolProperty(default = False, update = update_props, description = 'Push the objects away from a source object')
    custom_push_source : StringProperty(update = update_props, description = 'Push the objects away from this object')
    custom_local_rot : BoolProperty(default = False, update = update_props, description = 'Rotate the objects along their local axis')
    custom_seed : IntProperty(default = 1, min = 1, max = 1000000, update = update_props, description = 'Random seed')
    custom_time : FloatProperty(default = 0.0, min = 0.0, max = 1.0, update = update_time_props, description = 'Time')
    custom_time_control : BoolProperty(default = False, update = update_time_props, description = 'Control the time manually')    
   
class AnimaxGroup(PropertyGroup):
    coll : CollectionProperty(type=Animax)
    index : IntProperty()
    
    
############################################################################################
####################################### The UI #############################################
############################################################################################

# UI list draw (ANIMAX)
class SCENE_UL_animax(UIList):
   
   def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
       row = layout.row()       
       collections = bpy.data.collections.keys()
       ico = 'ERROR'
       if item.name in collections:
           ico = 'RADIOBUT_ON' if item.fx_enabled else 'RADIOBUT_OFF'         
       row.prop(item, "name", text="", emboss=False, icon = ico)
       row = layout.row()
       row.alignment = 'RIGHT'
       select = row.operator("animax.select_objects", icon = 'RESTRICT_SELECT_OFF', emboss = False, text = '')
       select.collection_name = item.name
       row.prop(item, "fx_enabled", text="")
       
# Settings Menu
class ANIMAX_MT_settings(Menu):
    bl_idname = "animax.settings"
    bl_label = "Settings"
    bl_description = "Settings"        

    def draw(self, context):
        scn = context.scene
        layout = self.layout
        layout.prop(scn,"animax_interactive", text = 'Interactive')        
        layout.separator()
        layout.separator()
        layout.operator("animax.get_selection_order", icon='RESTRICT_SELECT_OFF')
        layout.separator()
        layout.separator()
        layout.operator("animax.add_available_collections", icon = 'GROUP')
        layout.operator("animax.delete_all", icon = 'PANEL_CLOSE')
        layout.operator("animax.clear_all_delta", icon = 'LOOP_BACK')
        layout.separator()
        layout.separator()
        layout.operator("animax.enable_all", icon = 'RADIOBUT_ON')
        layout.operator("animax.disable_all", icon = 'RADIOBUT_OFF')
        layout.operator("animax.solo_selected", icon = 'RESTRICT_SELECT_OFF')
        layout.separator()
        layout.separator()
        layout.operator("animax.bake", icon = 'PMARKER_ACT')        
        layout.operator("animax.bake_shapes", icon = 'MESH_DATA')        
        layout.operator("animax.clear_kayframes", icon = 'PMARKER_SEL')      
       
# ANIMAX Panel
class ANIMAX_PT_main(Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "ANIMAX"
    bl_label = "ANIMAX"
    bl_context = "objectmode"
    
        
    def draw(self, context):
        layout = self.layout        
        scn = context.scene
        tab = scn.animax_tabs 
        collections = bpy.data.collections
        coll, index = get_animax_collection()
        row = layout.row()
        row.prop(scn, "animax_tabs", expand = True)
        if tab == 'Animate':                     
            row = layout.row()
            row.template_list("SCENE_UL_animax", "coll", scn.animax_collection, "coll", scn.animax_collection, "index", rows = 3)  
            col = row.column(align=True)
            col.prop(scn, 'animax_avail_collections', text = '', icon = 'ADD', icon_only=True)
            col.operator("animax.delete", icon='REMOVE', text = '')
            col.operator("animax.clear_delta", icon='LOOP_BACK', text = '')
            col.menu("animax.settings", text = '', icon = 'DOWNARROW_HLT')
                     
            
            if len(coll)>0:
                item = coll[index] 
                col = layout.column()                        
                if item.fx_enabled and item.name in collections:
                    if len(collections[item.name].objects) == 0:
                        col.label(text = 'Empty collection!', icon = 'ERROR') 
                    else:    
                        col = layout.column()
                        if 'animax_sorted_colls' in scn:
                            if not item.name in scn['animax_sorted_colls']:
                                col.label(text = "The objects aren't sorted", icon='ERROR')
                                col.operator("animax.sort_objects", icon='SORTSIZE')
                            else:
                                if not len(collections[item.name].objects) == scn['animax_sorted_colls'][item.name]['Count']:
                                    col.label(text = "The objects aren't sorted", icon='ERROR')
                                    col.operator("animax.sort_objects", icon='SORTSIZE')
                                else:                            
                                    col.operator("animax.sort_objects", icon='SORTSIZE')                 
                                    col = layout.column()               
                                    col.prop(item, "fx", text = '', icon = 'SHADERFX')
                                    col = layout.column()
                                    col = layout.column()
                                    col = layout.column()
                                    
                                    if item.fx != 'None':
                                        row = col.row(align = True)
                                        row.prop(item, "direction", icon = 'UV_SYNC_SELECT')
                                        row.operator("animax.sort_direction", icon='FILE_REFRESH', text = '')
                                        if item.direction == 'Random':
                                            col.prop(item, "random_seed", text = "Seed")
                                            
                                        
                                    if item.fx == 'Transformer':                
                                        col.prop(item, "transformer_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.transformer_time_control:
                                            row = layout.row()
                                            row.prop(item, "transformer_in_out", expand = True)
                                        col = layout.column()
                                        if item.transformer_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "transformer_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                            
                                        else:
                                            col.prop(item, "transformer_start", text = "Start")
                                        col.prop(item, "transformer_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "transformer_duration_offset", text = "Duration offset")                    
                                        col.prop(item, "transformer_distance", text = "Distance")
                                        col.prop(item, "transformer_seed", text = "Random seed")                                        
                                        col.prop(item, "transformer_push", text = "Push Away", icon = 'FORCE_FORCE')
                                        if item.transformer_push:
                                            row = col.row(align = True)
                                            row.prop_search(item, "transformer_push_source", bpy.data, "objects", text = '')
                                            picker = row.operator("animax.object_picker", icon = 'EYEDROPPER', text = '')
                                            picker.prop = 'Trans'
                                            picker.collection_name = item.name
                                        if not item.transformer_time_control:
                                            end = item.transformer_start +item.transformer_duration_per_ob +\
                                            item.transformer_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                        
                                    elif item.fx == 'Shoot':
                                        col.prop(item, "shoot_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.shoot_time_control:
                                            row = layout.row()
                                            row.prop(item, "shoot_in_out", expand = True)
                                        col = layout.column()
                                        if item.shoot_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "shoot_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')
                                        row = col.row(align = True)
                                        row.prop_search(item, "shoot_source", scn, "objects", text = '')
                                        picker = row.operator("animax.object_picker", icon = 'EYEDROPPER', text = '')
                                        picker.prop = 'Shoot'
                                        picker.collection_name = item.name
                                        col = layout.column()                                        
                                        col.prop(item, "shoot_ease")
                                        if not item.shoot_time_control:
                                            col.prop(item, "shoot_start", text = "Start")
                                        col.prop(item, "shoot_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "shoot_duration_offset", text = "Duration offset")                    
                                        if not item.shoot_time_control:
                                            end = item.shoot_start +item.shoot_duration_per_ob +\
                                            item.shoot_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                        
                                    elif item.fx == 'Explode':
                                        col.prop(item, "explode_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.explode_time_control:
                                            row = layout.row()
                                            row.prop(item, "explode_in_out", expand = True)
                                        col = layout.column()
                                        if item.explode_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "explode_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                            
                                        else:
                                            col.prop(item, "explode_start", text = "Start")                                        
                                        col.prop(item, "explode_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "explode_duration_offset", text = "Duration offset")                    
                                        col.label(text = "Velocity:")                    
                                        row = layout.row(align = True)
                                        col1 = row.column()
                                        col1.prop(item, "explode_velocity", text = "")
                                        col2 = row.column()
                                        col2.prop(item, "explode_random", text = "", icon = 'RNDCURVE')
                                        col = layout.column()
                                        col.prop(item, "explode_gravity", text = "Gravity")
                                        col.prop(item, "explode_rotation", text = "Rotation")
                                        col.prop(item, "explode_seed", text = "Random seed")
                                        col.prop(item, "explode_up", text = "Up axis")
                                        if not item.explode_time_control:
                                            end = item.explode_start +item.explode_duration_per_ob +\
                                            item.explode_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                        
                                    elif item.fx == 'Sparks':
                                        col.prop(item, "sparks_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.sparks_time_control:
                                            row = layout.row()
                                            row.prop(item, "sparks_in_out", expand = True)
                                        col = layout.column()
                                        if item.sparks_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "sparks_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                            
                                        else:
                                            col.prop(item, "sparks_start", text = "Start")                                        
                                        col.prop(item, "sparks_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "sparks_duration_offset", text = "Duration offset")                    
                                        col.prop(item, "sparks_distance2", text = "Horizontal distance")
                                        col.prop(item, "sparks_distance", text = "Verticale distance")
                                        col.prop(item, "sparks_rotation", text = "Rotation")
                                        col.prop(item, "sparks_noise_freq", text = "Noise Frequency")
                                        col.prop(item, "sparks_seed", text = "Random seed")
                                        col.prop(item, "sparks_up", text = "Up axis")
                                        if not item.sparks_time_control:
                                            end = item.sparks_start +item.sparks_duration_per_ob +\
                                            item.sparks_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                        
                                    elif item.fx == 'Sparks_II':
                                        col.prop(item, "sparksii_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.sparksii_time_control:
                                            row = layout.row()
                                            row.prop(item, "sparksii_in_out", expand = True)
                                        col = layout.column()
                                        if item.sparksii_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "sparksii_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                            
                                        else:
                                            col.prop(item, "sparksii_start", text = "Start")                                        
                                        col.prop(item, "sparksii_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "sparksii_duration_offset", text = "Duration offset")                    
                                        col.prop(item, "sparksii_distance2", text = "Horizontal distance")
                                        col.prop(item, "sparksii_distance", text = "Verticale distance")
                                        col.prop(item, "sparksii_seed", text = "Random seed")
                                        col.prop(item, "sparksii_up", text = "Up axis")
                                        if not item.sparksii_time_control:
                                            end = item.sparksii_start +item.sparksii_duration_per_ob +\
                                            item.sparksii_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                        
                                    elif item.fx == 'Streaks':
                                        col.prop(item, "streaks_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.streaks_time_control:
                                            row = layout.row()
                                            row.prop(item, "streaks_in_out", expand = True)
                                        col = layout.column()
                                        if item.streaks_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "streaks_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                            
                                        else:
                                            col.prop(item, "streaks_start", text = "Start")
                                        col.prop(item, "streaks_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "streaks_duration_offset", text = "Duration offset")                    
                                        col.prop(item, "streaks_distance", text = "Streak length")
                                        col.prop(item, "streaks_seed", text = "Random seed")
                                        if not item.streaks_time_control:
                                            end = item.streaks_start +item.streaks_duration_per_ob +\
                                            item.streaks_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                        
                                    elif item.fx == 'Popcorn':
                                        col.prop(item, "popcorn_time_control", text = "Time Control", icon = 'TIME')                
                                        if not item.popcorn_time_control:
                                            row = layout.row()
                                            row.prop(item, "popcorn_in_out", expand = True)
                                        col = layout.column()
                                        if item.popcorn_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "popcorn_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                            
                                        else:
                                            col.prop(item, "popcorn_start", text = "Start")
                                        col.prop(item, "popcorn_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "popcorn_duration_offset", text = "Duration offset")                    
                                        col.prop(item, "popcorn_distance", text = "Distance")
                                        col.prop(item, "popcorn_rotation", text = "Rotation")
                                        col.prop(item, "popcorn_scale", text = "Scale")
                                        col.prop(item, "popcorn_seed", text = "Random seed")
                                        if not item.popcorn_time_control:
                                            end = item.popcorn_start +item.popcorn_duration_per_ob +\
                                            item.popcorn_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                        
                                    elif item.fx == 'Smooth':
                                        col.prop(item, "smooth_time_control", text = "Time Control", icon = 'TIME')                
                                        if not item.smooth_time_control:
                                            row = layout.row()
                                            row.prop(item, "smooth_in_out", expand = True)
                                        col = layout.column()
                                        if item.smooth_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "smooth_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                            
                                        else:
                                            col.prop(item, "smooth_start", text = "Start")
                                        col.prop(item, "smooth_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "smooth_duration_offset", text = "Duration offset")                    
                                        col.prop(item, "smooth_distance", text = "Distance")
                                        col.prop(item, "smooth_rotation", text = "Rotation")                    
                                        col.prop(item, "smooth_seed", text = "Random seed")
                                        if not item.smooth_time_control:
                                            end = item.smooth_start +item.smooth_duration_per_ob +\
                                            item.smooth_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                        
                                    elif item.fx == 'Butterflies':
                                        col.prop(item, "butterfly_time_control", text = "Time Control", icon = 'TIME')                
                                        if not item.butterfly_time_control:
                                            row = layout.row()
                                            row.prop(item, "butterfly_in_out", expand = True)
                                        col = layout.column()
                                        if item.butterfly_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "butterfly_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                            
                                        else:
                                            col.prop(item, "butterfly_start", text = "Start")
                                        col.prop(item, "butterfly_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "butterfly_duration_offset", text = "Duration offset")                    
                                        col.prop(item, "butterfly_distance", text = "Distance")
                                        col.prop(item, "butterfly_vibration", text = "Vibration")                    
                                        col.prop(item, "butterfly_vibration_angle", text = "Vibration Angle")                    
                                        col.prop(item, "butterfly_seed", text = "Random seed")
                                        if not item.butterfly_time_control:
                                            end = item.butterfly_start +item.butterfly_duration_per_ob +\
                                            item.butterfly_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                        
                                    elif item.fx == 'Spiral':
                                        col.prop(item, "spiral_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.spiral_time_control:
                                            row = layout.row()
                                            row.prop(item, "spiral_in_out", expand = True)
                                        col = layout.column()
                                        if item.spiral_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "spiral_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                            
                                        else:
                                            col.prop(item, "spiral_start", text = "Start")
                                        col.prop(item, "spiral_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "spiral_duration_offset", text = "Duration offset")                    
                                        col.prop(item, "spiral_turns") 
                                        col.prop(item, "spiral_distance", text = "Distance") 
                                        col.prop(item, "spiral_offset", text = "Offset") 
                                        col.prop(item, "spiral_up", text = "Up axis")
                                        if item.spiral_up == 'Random':
                                            col.prop(item, "spiral_seed", text = "Random seed")
                                        if not item.spiral_time_control:    
                                            end = item.spiral_start +item.spiral_duration_per_ob +\
                                            item.spiral_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                        
                                    elif item.fx == 'Smooth_II':
                                        col.prop(item, "smoothii_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.smoothii_time_control:
                                            row = layout.row()
                                            row.prop(item, "smoothii_in_out", expand = True)
                                        col = layout.column()
                                        if item.smoothii_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "smoothii_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                            
                                        else:
                                            col.prop(item, "smoothii_start", text = "Start")
                                        col.prop(item, "smoothii_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "smoothii_duration_offset", text = "Duration offset")                    
                                        col.prop(item, "smoothii_turns") 
                                        col.prop(item, "smoothii_distance", text = "Distance")
                                        col.prop(item, "smoothii_rotation", text = "Rotation")
                                        col.prop(item, "smoothii_seed", text = "Random seed")
                                        if not item.smoothii_time_control:
                                            end = item.smoothii_start +item.smoothii_duration_per_ob +\
                                            item.smoothii_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                        
                                    elif item.fx == 'Wiggle':
                                        col.prop(item, "wiggle_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.wiggle_time_control:
                                            row = layout.row()
                                            row.prop(item, "wiggle_in_out", expand = True)
                                        col = layout.column()
                                        if item.wiggle_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "wiggle_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                            
                                        else:
                                            col.prop(item, "wiggle_start", text = "Start")
                                        col.prop(item, "wiggle_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "wiggle_duration_offset", text = "Duration offset")
                                        col.prop(item, "wiggle_distance", text = "Distance")
                                        col.prop(item, "wiggle_rotation", text = "Rotation")
                                        col.prop(item, "wiggle_comp", text = 'Complexity') 
                                        col.prop(item, "wiggle_distortion", text = 'Distortion') 
                                        col.prop(item, "wiggle_seed", text = "Random seed")
                                        if not item.wiggle_time_control:
                                            end = item.wiggle_start +item.wiggle_duration_per_ob +\
                                            item.wiggle_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                        
                                    elif item.fx == 'Zigzag':
                                        col.prop(item, "zigzag_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.zigzag_time_control:
                                            row = layout.row()
                                            row.prop(item, "zigzag_in_out", expand = True)
                                        col = layout.column()
                                        if item.zigzag_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "zigzag_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                            
                                        else:
                                            col.prop(item, "zigzag_start", text = "Start")
                                        col.prop(item, "zigzag_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "zigzag_duration_offset", text = "Duration offset")
                                        col.prop(item, "zigzag_distance", text = "Distance")
                                        col.prop(item, "zigzag_rotation", text = "Rotation")                                        
                                        col.prop(item, "zigzag_seed", text = "Random seed")
                                        if not item.zigzag_time_control:
                                            end = item.zigzag_start +item.zigzag_duration_per_ob +\
                                            item.zigzag_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO') 
                                    
                                    elif item.fx == 'Rain':
                                        col.prop(item, "rain_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.rain_time_control:
                                            row = layout.row()
                                            row.prop(item, "rain_in_out", expand = True)
                                        col = layout.column()
                                        if item.rain_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "rain_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                            
                                        else:
                                            col.prop(item, "rain_start", text = "Start")
                                        col.prop(item, "rain_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "rain_duration_offset", text = "Duration offset")                    
                                        col.prop(item, "rain_distance", text = "Distance")
                                        col.prop(item, "rain_length", text = "Drops Length")
                                        col.prop(item, "rain_up", text = "Up axis")
                                        if not item.rain_time_control:
                                            end = item.rain_start +item.rain_duration_per_ob +\
                                            item.rain_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                            
                                    elif item.fx == 'Collapse':
                                        col.prop(item, "collapse_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.collapse_time_control:
                                            row = layout.row()
                                            row.prop(item, "collapse_in_out", expand = True)
                                        col = layout.column()
                                        if item.collapse_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "collapse_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                        
                                        col = layout.column()                                        
                                        if not item.collapse_time_control:
                                            col.prop(item, "collapse_start", text = "Start")
                                        col.prop(item, "collapse_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "collapse_duration_offset", text = "Duration offset")
                                        col.prop(item, "collapse_floor", text = 'Floor')
                                        col.prop(item, "collapse_spread", text = 'Spread')
                                        col.prop(item, "collapse_rotation", text = 'Rotation')
                                        col.prop(item, "collapse_seed", text = 'Random seed')
                                        col.prop(item, "collapse_axis", text = 'Floor axis')
                                        col.prop(item, "collapse_scale", text = 'Fade out')
                                        if not item.collapse_time_control:
                                            end = item.collapse_start +item.collapse_duration_per_ob +\
                                            item.collapse_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                            
                                    elif item.fx == 'Elastic':
                                        col.prop(item, "elastic_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.elastic_time_control:
                                            row = layout.row()
                                            row.prop(item, "elastic_in_out", expand = True)
                                        col = layout.column()
                                        if item.elastic_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "elastic_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                        
                                        col = layout.column()                                        
                                        if not item.elastic_time_control:
                                            col.prop(item, "elastic_start", text = "Start")
                                        col.prop(item, "elastic_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "elastic_duration_offset", text = "Duration offset")
                                        col = layout.column(align = True)                        
                                        col.prop(item, "elastic_location", text = 'Location')
                                        col.prop(item, "elastic_elasticity", index = 0)
                                        col.prop(item, "elastic_slowdown", index = 0)
                                        col = layout.column(align = True)                        
                                        col.prop(item, "elastic_rotation")
                                        col.prop(item, "elastic_elasticity", index = 1)
                                        col.prop(item, "elastic_slowdown", index = 1)
                                        col = layout.column(align = True)
                                        col.label(text = 'Scale')                        
                                        col.prop(item, "elastic_scale_start", text = 'Initial Scale')
                                        col.prop(item, "elastic_scale_amplitude", text = 'Scale Amplitude')
                                        col.prop(item, "elastic_elasticity", index = 2)
                                        col.prop(item, "elastic_slowdown", index = 2)
                                        if not item.elastic_time_control:
                                            end = item.elastic_start +item.elastic_duration_per_ob +\
                                            item.elastic_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')        
                                        
                                    elif item.fx == 'Copy_animation':
                                        col.prop(item, "copy_time_control", text = "Time Control", icon = 'TIME')                
                                        if not item.copy_time_control:
                                            row = layout.row()
                                            row.prop(item, "copy_in_out", expand = True)
                                        col = layout.column()
                                        if item.copy_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "copy_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                        
                                        row = col.row(align = True)    
                                        row.prop_search(item,"copy_source", scn, "objects", text = '')
                                        picker = row.operator("animax.object_picker", icon = 'EYEDROPPER', text = '')
                                        picker.prop = 'Copy'
                                        picker.collection_name = item.name
                                        if not item.copy_time_control:
                                            col.prop(item, "copy_start", text = "Start")
                                        fcs, indexs, rang, starts = avail_fcurves(item.copy_source[3 : ])                    
                                        col.prop(item, "copy_duration_offset", text = "Duration offset")
                                        col.prop(item, "copy_local_rot", text = 'Local Rotation', icon = 'NDOF_TURN')
                                        if item.copy_source[3 : ]:
                                            if len(fcs) > 0:
                                                if not item.copy_time_control:
                                                    col.label(text = 'Source duration: ' + str(rang), icon = 'INFO')                                     
                                                    end = item.copy_start + rang + item.copy_duration_offset - 1
                                                    col.label(text = "End frame: " + str(end), icon = 'INFO')
                                            else:
                                                col.label(text = 'No animation found!', icon = 'ERROR')
                                        else:
                                            col.label(text = 'A Source object is required!', icon = 'ERROR')                                            
                                            
                                    elif item.fx == 'Follow_Curve':
                                        col.prop(item, "follow_time_control", text = "Time Control", icon = 'TIME')                
                                        if not item.follow_time_control:
                                            row = layout.row()
                                            row.prop(item, "follow_in_out", expand = True)
                                        col = layout.column()
                                        if item.follow_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "follow_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')
                                        row = col.row(align = True)    
                                        row.prop_search(item, "follow_curve", bpy.data, "curves", text = '')
                                        picker = row.operator("animax.object_picker", icon = 'EYEDROPPER', text = '')
                                        picker.prop = 'Follow'
                                        picker.collection_name = item.name
                                        if not scn.objects.get(item.follow_curve[3 : ]):
                                            col.label(text = 'A bezier curve is required.', icon = 'ERROR')
                                        else:
                                            if not scn.objects[item.follow_curve[3 : ]].type == 'CURVE':
                                                col.label(text = 'A bezier curve is required.', icon = 'ERROR')
                                            else:    
                                                if not len(scn.objects[item.follow_curve[3 : ]].data.splines) > 0:
                                                    col.label(text = 'Not enought points in the Curve.', icon = 'ERROR')
                                                else:    
                                                    if not scn.objects[item.follow_curve[3 : ]].data.splines[0].type == 'BEZIER':
                                                        col.label(text = 'Only Bezier curves are supported.', icon = 'ERROR')
                                                    else:
                                                        if not item.follow_time_control:
                                                            col.prop(item, "follow_start", text = "Start")
                                                        col.prop(item, "follow_duration_per_ob", text = "Duration per_object")
                                                        col.prop(item, "follow_duration_offset", text = "Duration offset")                                        
                                                        col.prop(item, "follow_scale", text = "Scale")                                        
                                                        col.prop(item, "follow_rotation", text = "Rotation")                                        
                                                        col.prop(item, "follow_noise", text = "Add noise")
                                                        if item.follow_noise > 0:
                                                            col.prop(item, "follow_noise_freq", text = "Noise Frequency")                                        
                                                            col.prop(item, "follow_seed", text = "Random seed")
                                                        if not item.follow_time_control:    
                                                            end = item.follow_start +item.follow_duration_per_ob +\
                                                            item.follow_duration_offset
                                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                                        
                                    elif item.fx == 'Custom':
                                        col.prop(item, "custom_time_control", text = "Time Control", icon = 'TIME')
                                        if not item.custom_time_control:
                                            row = layout.row()
                                            row.prop(item, "custom_in_out", expand = True)
                                        col = layout.column()
                                        if item.custom_time_control:
                                            row = col.row(align = True)
                                            row.prop(item, "custom_time", text = "Time", slider = True)
                                            row.prop(scn, "animax_interactive", text = "", icon = 'PHYSICS')                                            
                                        else:
                                            col.prop(item, "custom_start", text = "Start")
                                        col.prop(item, "custom_duration_per_ob", text = "Duration per_object")
                                        col.prop(item, "custom_duration_offset", text = "Duration offset")                    
                                        col.prop(item, "custom_seed", text = "Random seed")
                                        if not item.custom_time_control:
                                            end = item.custom_start +item.custom_duration_per_ob +\
                                            item.custom_duration_offset
                                            col.label(text = "End frame: " + str(end), icon = 'INFO')
                                        box = col.box()                    
                                        box.prop(scn, "animax_expand_pre",
                                        icon="TRIA_DOWN" if scn.animax_expand_pre else "TRIA_RIGHT",
                                        icon_only=True, emboss = False, text = 'Presets')                    
                                        if scn.animax_expand_pre:
                                            if os.path.exists(presets_folder):
                                                row = box.row(align = True)
                                                row.prop(scn, "animax_presets", text = '')                                            
                                                row.operator("animax.load_preset", icon = 'FILE_PARENT', text = '')
                                                row.operator("animax.rename_preset", icon = 'GREASEPENCIL', text = '')
                                                row.operator("animax.delete_preset", icon = 'PANEL_CLOSE', text = "")
                                                row = box.row(align = True)
                                                row.prop(scn, "animax_preset_name", text = 'New')
                                                row.operator("animax.save_preset", icon = 'NEWFOLDER', text = '')                                            
                                                if preset_name_exists(scn.animax_preset_name + '.animax'):
                                                    box.label(text = 'This name already exists!', icon = 'ERROR')
                                            else:
                                                row = box.row()
                                                row.label(text = "The presets folder doesn't exists", icon = 'ERROR')
                                                row = box.row()
                                                row.label(text = "  Reinstalling the add-on may solve this problem")
                                            row = box.row()    
                                        box = col.box()                    
                                        box.prop(item, "custom_expand_loc",
                                        icon="TRIA_DOWN" if item.custom_expand_loc else "TRIA_RIGHT",
                                        icon_only=True, emboss = False, text = 'Location')                    
                                        if item.custom_expand_loc:
                                            box.prop(item, "custom_push_away", text = 'Push Away', icon = 'FORCE_FORCE')
                                            if item.custom_push_away:
                                                row = box.row(align = True)
                                                row.prop_search(item, "custom_push_source", bpy.data, "objects", text = '')
                                                picker = row.operator("animax.object_picker", icon = 'EYEDROPPER', text = '')
                                                picker.prop = 'Custom'
                                                picker.collection_name = item.name
                                            box.prop(item, "custom_location", text = '')
                                            box.prop(item, "custom_location_ease")
                                            row = box.row(align = True)                    
                                            row.prop(item, "custom_random", index = 0, text = 'Randomize')
                                            row.prop(item, "custom_neg", index = 0, text = '', icon = 'ADD')
                                            row.prop(item, "custom_additive", index = 0, text = '', icon = 'REMOVE')
                                        box = col.box()
                                        box.prop(item, "custom_expand_rot",
                                        icon="TRIA_DOWN" if item.custom_expand_rot else "TRIA_RIGHT",
                                        icon_only=True, emboss = False, text = 'Rotation')                    
                                        if item.custom_expand_rot:
                                            box.prop(item, "custom_local_rot", text = 'Local Rotation', icon = 'NDOF_TURN')
                                            box.prop(item, "custom_rotation", text = "")
                                            box.prop(item, "custom_rotation_ease")
                                            row = box.row(align = True) 
                                            row.prop(item, "custom_random", index = 1, text = 'Randomize')
                                            row.prop(item, "custom_neg", index = 1, text = '', icon = 'ADD')
                                            row.prop(item, "custom_additive", index = 1, text = '', icon = 'REMOVE')
                                        box = col.box()
                                        box.prop(item, "custom_expand_scale",
                                        icon="TRIA_DOWN" if item.custom_expand_scale else "TRIA_RIGHT",
                                        icon_only=True, emboss = False, text = 'Scale')                    
                                        if item.custom_expand_scale:                    
                                            box.prop(item, "custom_scale", text = "")
                                            box.prop(item, "custom_scale_ease")
                                            row = box.row(align = True)
                                            row.prop(item, "custom_random", index = 2, text = 'Randomize')
                                            row.prop(item, "custom_neg", index = 2, text = '', icon = 'ADD')
                                            row.prop(item, "custom_additive", index = 2, text = '', icon = 'REMOVE')
            
        # Split tab
        elif tab == 'Split':
            if not context.object:
                col = layout.column()
                col.label(text ='An Active object is required !', icon = 'ERROR') 
            else:                
                ob = context.object
                modifiers = ob.modifiers
                col = layout.column()                
                col.label(text ='Active object: ' + ob.name, icon = 'OBJECT_DATA')                
                col = layout.column()
                if not 'ANIMAX SPLIT' in ob:
                    if not ob.type == 'MESH':
                        if ob.type in ['META','FONT', 'SURFACE', 'CURVE']:
                            col.label(text = 'Only Mesh objects are supported!', icon = 'INFO')
                            convert = col.operator("object.convert", text = 'Convert to Mesh', icon = 'MESH_DATA')
                            convert.target = 'MESH'
                            if ob.type == 'FONT':
                                col = layout.column()
                                col = layout.column()
                                col = layout.column()
                                col.prop(ob, "animax_collection_name", text = 'New collection')
                                col.operator("animax.separate_letters", icon = 'FILE_FONT')
                                
                    else:
                        if len(ob.modifiers) >0:
                            col.label(text = 'Please, Apply the modifiers', icon = 'ERROR')
                            col.label(text = 'result may not be as expected', icon = 'ERROR')
                        col.prop(ob, "animax_collection_name", text = 'New collection')    
                        col.prop(ob, "animax_keep_original", text = 'Keep original')                        
                        col.operator("animax.particles_spliting", icon = 'MOD_EXPLODE') 
                        col.operator("animax.split_faces", icon = 'MOD_ARRAY') 
                else:
                    if ob['ANIMAX SPLIT'] == 'NONE':
                        if len(ob.modifiers) >0:
                            col.label(text = 'Please, Apply the modifiers', icon = 'ERROR')
                            col.label(text = 'result may not be as expected', icon = 'ERROR')
                        col.prop(ob, "animax_collection_name", text = 'New collection')    
                        col.prop(ob, "animax_keep_original", text = 'Keep original')                        
                        col.operator("animax.particles_spliting", icon = 'MOD_EXPLODE')
                        col.operator("animax.split_faces", icon = 'MOD_ARRAY')
                    else:                        
                        if len(ob.particle_systems) > 0:
                            if 'ANIMAX PARTICLES' in ob.particle_systems:
                                particles = ob.particle_systems['ANIMAX PARTICLES']
                                col.prop(particles, 'seed')
                                col.prop(particles.settings, 'count')
                        if 'ANIMAX SUBSURF' in modifiers:
                            subsurf = modifiers['ANIMAX SUBSURF']
                            if subsurf.type == 'SUBSURF':
                                row = col.row(align = True)
                                row.prop(subsurf, 'levels', text = 'Sub divisions')
                                row.prop(subsurf, 'subdivision_type', text = '')
                        if 'ANIMAX TRIANGULATE' in modifiers:
                            tri = modifiers['ANIMAX TRIANGULATE']
                            if tri.type == 'TRIANGULATE':
                                col.prop(tri, 'show_viewport', text = 'Triangulate', icon = 'MOD_TRIANGULATE')
                        if 'ANIMAX SOLIDIFY' in modifiers:
                            solid = modifiers['ANIMAX SOLIDIFY']
                            if solid.type == 'SOLIDIFY':                            
                                col.prop(solid, 'show_viewport', text = 'Solidify', icon = 'MOD_SOLIDIFY')
                                if solid.show_viewport:
                                    col.prop(solid, 'thickness')
                        if 'ANIMAX EXPLODE' in modifiers:
                            exp = modifiers['ANIMAX EXPLODE']
                            if exp.type == 'EXPLODE':                            
                                col.prop(exp, 'use_edge_cut', icon = 'MOD_BOOLEAN')
                                col.prop(exp, 'use_size', text = 'Preview shards', icon = 'MOD_BUILD')
                        col = layout.column()        
                        col = layout.column()        
                        row = col.row()        
                        row.operator("animax.apply_shards", icon = 'FILE_TICK')        
                        row.operator("animax.cancel_splitting", icon = 'CANCEL')        
                        
                        
                                        
                                    
                                    
                                    
        
        
############################################################################################
################################ Register/Unregister #######################################
############################################################################################

classes = (
    ANIMAX_OT_add_collections,
    ANIMAX_OT_delete_collection,
    ANIMAX_OT_delete_collections,
    ANIMAX_OT_enable_collections,
    ANIMAX_OT_disable_collections,
    ANIMAX_OT_solo_selected_collection,
    ANIMAX_OT_select_collection_objects,
    ANIMAX_OT_clear_collection_deltas,
    ANIMAX_OT_clear_collections_deltas,
    ANIMAX_OT_sort_objects,
    ANIMAX_OT_sort_single_direction,
    ANIMAX_OT_bake_to_keyframes,
    ANIMAX_OT_bake_to_shapekeys,
    ANIMAX_OT_free_bake,
    ANIMAX_OT_object_picker,
    ANIMAX_OT_get_selection_order,
    ANIMAX_OT_particles_spliting,
    ANIMAX_OT_apply_shards,
    ANIMAX_OT_split_faces,
    ANIMAX_OT_separate_letters,
    ANIMAX_OT_cancel_split,
    ANIMAX_OT_save_preset,
    ANIMAX_OT_load_preset,
    ANIMAX_OT_delete_preset,
    ANIMAX_OT_rename_preset,
    Animax,
    AnimaxGroup,
    SCENE_UL_animax,
    ANIMAX_MT_settings,
    ANIMAX_PT_main,    
)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
        
    bpy.types.Scene.animax_collection = PointerProperty(type=AnimaxGroup)
    bpy.types.Scene.animax_avail_collections = EnumProperty(name = 'Available collections', items = collections_list, update = add_collection,
                                                       description = 'Available collections')
    bpy.types.Scene.animax_interactive = BoolProperty(default = True, description = 'View the change of parameters in real time')    
    bpy.types.Scene.animax_tabs = EnumProperty(items = (('Animate', 'Animate', ''), ('Split', 'Split', '')), description = 'What you want to do?')    
    bpy.types.Object.animax_collection_name = StringProperty(default = 'ANIMAX', description = 'Name of the new collection')
    bpy.types.Object.animax_keep_original = BoolProperty(default = True, description = 'Keep the original object, the newly shattered objects will be created in a new collection')    
    bpy.types.Scene.animax_presets = EnumProperty(name = 'Presets', items = presets_list, description = 'Presets')
    bpy.types.Scene.animax_expand_pre = BoolProperty(default = False, update = update_props, description = 'Expand/collapse this menu')
    bpy.types.Scene.animax_preset_name = StringProperty(default = '', description = 'Name of the new preset')
    bpy.types.Scene.animax_timer_running = BoolProperty(default = False)
    
    frame_change_pre.append(update_animax)    

def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)

    del bpy.types.Scene.animax_collection 
    del bpy.types.Scene.animax_avail_collections    
    del bpy.types.Scene.animax_interactive
    del bpy.types.Scene.animax_tabs    
    del bpy.types.Object.animax_collection_name
    del bpy.types.Object.animax_keep_original    
    del bpy.types.Scene.animax_presets
    del bpy.types.Scene.animax_expand_pre
    del bpy.types.Scene.animax_preset_name
    del bpy.types.Scene.animax_timer_running
    
    frame_change_pre.remove(update_animax)    

if __name__ == "__main__":
    register()